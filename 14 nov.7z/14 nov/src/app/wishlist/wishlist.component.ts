import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService, WishListToCartProduct } from '../product-service.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  router: Router;
  service: ProductServiceService; // creating service object of ServiceService class 

 

  wishlistProducts: WishListToCartProduct[] = []
  constructor(service: ProductServiceService, router: Router) {

    this.service = service;
    this.router = router;
   }

  ngOnInit() {
    this.service.getWishlistProducts().subscribe(data => this.wishlistProducts = data)
  }

}
