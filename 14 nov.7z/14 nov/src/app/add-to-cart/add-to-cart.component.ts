import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService, AddToCartProduct } from '../product-service.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {

  router: Router;
  service: ProductServiceService; // creating service object of ServiceService class 

 

  cartProducts: AddToCartProduct[] = []

  constructor(service: ProductServiceService, router: Router) { 
    this.service = service;
    this.router = router;
  }

  ngOnInit() {
    this.service.getCartProducts().subscribe(data => this.cartProducts = data)
  }

}
