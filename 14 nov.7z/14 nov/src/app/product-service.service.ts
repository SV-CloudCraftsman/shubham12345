import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Type } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  url: string = " http://localhost:8585/customer/";

  constructor(private http:HttpClient) { 
    this.http=http;
  }

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
  fetched:boolean=false;

  fetchProducts(productId) :Promise<any>
{
  return this.http.get(this.url + 'fetchProduct/'+productId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
// return this.http.get<Products[]>('http://localhost:8585/customer/fetchAllProducts');
}

getProducts():Observable<Products[]>{
  return this.http.get<Products[]>(this.url + "/fetchAll");
   
}

getCartProducts():Observable<AddToCartProduct[]>
{
  return this.http.get<AddToCartProduct[]>(this.url +"/fetchCartAll");
}

getWishlistProducts():Observable<WishListToCartProduct[]>
{
  return this.http.get<WishListToCartProduct[]>(this.url +"fetchWishlistAll")
}

addToCart(product:Products):Observable<void>
{
  return this.http.put<void>(`$(this.url)/$(addToCart)/$(product.productId)`,product)
  {
    headers:new HttpHeaders({
      'Content-Type':'application.json'
    })
  };
}

// addtocart(productId): Promise<any> {
//   window.alert("shubham");
//   return this.http.post(this.url + 'addToCart/' +productId)
//     .toPromise()
//     .then(response => response)
//     .catch(this.handleError);
//     window.alert("Items successfully added to cart")
// }

// public addtocart(productId:number)
// {
//   return this.http.post(this.url + 'addToCart/'+productId);
// }

// public buynow(customerId:number )
// {
//   return this.http.post<number>(this.url+"/addOrder/"+customerId,{responseType:'number'})
// }

}

export class Products
{
  productId:number;
  productName:string;
  productType:string;
  productPrice:number;
  productDescription:string;
  productAvailability:number;
  constructor(productId:number,productName:string,productType:string,productPrice:number,productDescription:string,productAvailability:number)
  {
    this.productId=productId;
    this.productType=productType;
    this.productName=productName;
    this.productPrice=productPrice;
    this.productDescription=productDescription;
    this.productAvailability=productAvailability;
  }
}

export class AddToCartProduct
{
  cartId:number;
  productId:number;
  productQty:number;
  productName:string;
  productPrice:number;

  constructor(cartId:number,productId:number,productQty:number,productName:string,productPrice:number)
  {
    this.cartId=cartId;
    this.productId=productId;
    this.productQty=productQty;
    this.productName=productName;
    this.productPrice=productPrice;
  }
}

export class WishListToCartProduct
{
  wishlistId:number;
  productId:number;
  productQty:number;
  productName:string;
  productPrice:number;

  constructor(wishlistId:number,productId:number,productQty:number,productName:string,productPrice:number)
  {
    this.wishlistId=wishlistId;
    this.productId=productId;
    this.productQty=productQty;
    this.productName=productName;
    this.productPrice=productPrice;
  }
}
