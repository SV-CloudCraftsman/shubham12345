package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_addtocarts")
public class AddToCartProduct {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cart_seq_gen")
	@SequenceGenerator(name = "cart_seq_gen", initialValue = 1000, sequenceName = "cart_seq") // to be created
	private int cartId;

	@Column
	private int productId;

	@Column
	private int productQty;

	@Column
	private String productName;

	@Column
	private double productPrice;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public AddToCartProduct(int cartId, int productId, int productQty, String productName, double productPrice) {
		super();
		this.cartId = cartId;
		this.productId = productId;
		this.productQty = productQty;
		this.productName = productName;
		this.productPrice = productPrice;
	}

public AddToCartProduct() {
	// TODO Auto-generated constructor stub
}


}