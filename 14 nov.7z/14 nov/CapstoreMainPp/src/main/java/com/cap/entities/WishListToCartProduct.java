package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "capstore_wishlists")
public class WishListToCartProduct {

		@Id
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wishlist_seq_gen")
		@SequenceGenerator(name = "wishlist_seq_gen", initialValue = 1000, sequenceName = "wishlist_seq_gen")
		private int wishlistId;
		
		@Column
		private int productId;
		
		
		
		@Column
		private int productQty;
		
		@Column
		private String productName;
		
		@Column
		private double productPrice;
		
		@ManyToOne
		
		private Merchant merchant;
		
		@ManyToOne
		
		private Product products;
		
		public Merchant getMerchant() {
			return merchant;
		}
		public void setMerchant(Merchant merchant) {
			this.merchant = merchant;
		}
		public Product getProducts() {
			return products;
		}
		public void setProducts(Product products) {
			this.products = products;
		}
		
		public int getWishlistId() {
			return wishlistId;
		}
		public void setWishlistId(int wishlistId) {
			this.wishlistId = wishlistId;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public int getProductQty() {
			return productQty;
		}
		public void setProductQty(int productQty) {
			this.productQty = productQty;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public double getProductPrice() {
			return productPrice;
		}
		public void setProductPrice(double productPrice) {
			this.productPrice = productPrice;
		}
		public WishListToCartProduct() {
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public String toString() {
			return "WishListToCartProduct [wishlistId=" + wishlistId + ", merchant=" + merchant + ", products="
					+ products + "]";
		}
		public WishListToCartProduct(int wishlistId, int productId, int productQty, String productName,
				double productPrice, Merchant merchant, Product products) {
			super();
			this.wishlistId = wishlistId;
			this.productId = productId;
			this.productQty = productQty;
			this.productName = productName;
			this.productPrice = productPrice;
			this.merchant = merchant;
			this.products = products;
		}
		
		
		
}
