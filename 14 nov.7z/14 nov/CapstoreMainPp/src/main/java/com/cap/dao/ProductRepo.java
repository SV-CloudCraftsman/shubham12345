package com.cap.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cap.entities.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product,Long> {

	@Query("from Product where productId=?1")
    public Product findById(int productId);

	

}
