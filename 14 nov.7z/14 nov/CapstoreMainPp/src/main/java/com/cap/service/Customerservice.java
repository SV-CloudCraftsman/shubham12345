package com.cap.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Order;
import com.cap.entities.Product;
import com.cap.entities.WishListToCartProduct;

public interface Customerservice {

	Product fetchProduct(int productId);

	List<Product> addProducts(Product product);

	AddToCartProduct addToCart(int productId);
	
	WishListToCartProduct addtowishlist(int productId);

	Order buyNow(int productId) throws SQLException;

	List<Product> fetchAll();

	List<AddToCartProduct> fetchCartAll();

	List<WishListToCartProduct> fetchWishlistAll();




}
