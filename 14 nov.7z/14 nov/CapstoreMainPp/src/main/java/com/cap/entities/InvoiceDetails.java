package com.cap.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="capstore_invoice")
public class InvoiceDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "invoice_seq_gen")
	@SequenceGenerator(name = "invoice_seq_gen", initialValue = 100000, sequenceName = "invoice_seq")
	private long invoiceId;

	 @ManyToOne
	 @JoinColumn
	 private TransactionDetails transaction;
	 
	 @ManyToOne
	 @JoinColumn
	 private Product product;
	    
	 @ManyToOne
	 @JoinColumn(name = "email")
	 private Merchant merchant;
	 
	 @ManyToOne
	 @JoinColumn
	 private Order order;
	 
	 @ManyToOne
	 @JoinColumn
	 private Customer customer;

	public InvoiceDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvoiceDetails(long invoiceId, TransactionDetails transactionDetails, Product product, Merchant merchant,
			Order order, Customer customer) {
		super();
		this.invoiceId = invoiceId;
		this.transaction = transactionDetails;
		this.product = product;
		this.merchant = merchant;
		this.order = order;
		this.customer = customer;
	}

	public long getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	public TransactionDetails getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionDetails transaction) {
		this.transaction = transaction;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
