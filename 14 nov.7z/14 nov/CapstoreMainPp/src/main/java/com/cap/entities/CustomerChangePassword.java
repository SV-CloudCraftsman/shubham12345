package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_chnge_pass")
public class CustomerChangePassword {
	    
    @Id
    @Column(length=30)
    private String custEmail;
    
    @Column(length=20)
    private String currPass;
    
    @Column(length=20)
    private String newPass;

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCurrPass() {
		return currPass;
	}

	public void setCurrPass(String currPass) {
		this.currPass = currPass;
	}

	public String getNewPass() {
		return newPass;
	}

	public void setNewPass(String newPass) {
		this.newPass = newPass;
	}
    
public CustomerChangePassword() {
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "CustomerChangePassword [custEmail=" + custEmail + ", currPass=" + currPass + ", newPass=" + newPass + "]";
}

public CustomerChangePassword(String custEmail, String currPass, String newPass) {
	super();
	this.custEmail = custEmail;
	this.currPass = currPass;
	this.newPass = newPass;
}


}