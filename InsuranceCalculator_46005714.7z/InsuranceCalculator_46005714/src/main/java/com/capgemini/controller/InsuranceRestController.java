package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.entity.InsuranceCalculatorEntity;
import com.capgemini.service.InsuranceService;

@RestController
@RequestMapping("/Insurance")
public class InsuranceRestController {
	
	@Autowired
	InsuranceService service;
	
	@PostMapping("/createInsurance")
	public List<InsuranceCalculatorEntity> addInsurance(@RequestBody InsuranceCalculatorEntity insurance)
	{
		return service.addInsurance(insurance);
		
	}
	
	@PutMapping("/updateInsurance/{id}")
	public List<InsuranceCalculatorEntity> updateInsurance(@PathVariable Integer id,@RequestBody InsuranceCalculatorEntity insurance) {
		System.out.println(id);
		System.out.println(insurance.getVehicleModel());
		return service.updateInsurance(id, insurance);
	}
	
	@DeleteMapping("/deleteInsurance/{id}")
	  public ResponseEntity deleteInsurance(@PathVariable int id)
	   
    {
        service.deleteInsurance(id);
        return new ResponseEntity("Insurance id="+id+" deleted",HttpStatus.OK);
       
    }
	
	public List<InsuranceCalculatorEntity> viewInsuranceById(@RequestBody InsuranceCalculatorEntity insurance)
	{
		return service.addInsurance(insurance);
		
	}
	
	

}
