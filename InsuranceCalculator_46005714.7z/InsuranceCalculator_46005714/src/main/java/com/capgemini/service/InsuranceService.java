package com.capgemini.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.capgemini.entity.InsuranceCalculatorEntity;

public interface InsuranceService {

	List<InsuranceCalculatorEntity> addInsurance(InsuranceCalculatorEntity insurance);
	public List<InsuranceCalculatorEntity> updateInsurance(Integer id,InsuranceCalculatorEntity insurance);
	public void deleteInsurance(Integer eid);
	public double calculateInsuranceAmount(double price, int year);
	public Optional<InsuranceCalculatorEntity> viewInsuranceById( Integer id);
	public List<InsuranceCalculatorEntity> viewAllInsurance();

	
}
