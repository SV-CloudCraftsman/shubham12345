package com.capgemini.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.dao.InsuranceDao;
import com.capgemini.entity.InsuranceCalculatorEntity;

@Service
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	InsuranceDao insuranceDao;
	
	@Override
	public List<InsuranceCalculatorEntity> addInsurance(InsuranceCalculatorEntity insurance) {
		// TODO Auto-generated method stub
		insuranceDao.save(insurance);
		return insuranceDao.findAll();
	}

	@Override
	public List<InsuranceCalculatorEntity> updateInsurance(Integer id, InsuranceCalculatorEntity insurance) {
		// TODO Auto-generated method stub
		Optional<InsuranceCalculatorEntity> e=insuranceDao.findById(id);
		InsuranceCalculatorEntity e1=e.get();
		
		e1.setId(insurance.getId());
		e1.setInsuranceAmount(insurance.getInsuranceAmount());
		e1.setOnRoadPrice(insurance.getOnRoadPrice());
		e1.setPurchaseYear(insurance.getPurchaseYear());
		e1.setVehicleModel(insurance.getVehicleModel());
		e1.setExpDate(insurance.getExpDate());
		
		insuranceDao.save(e1);
		
		return insuranceDao.findAll();
	}

	@Override
	public void deleteInsurance(Integer eid) {
		// TODO Auto-generated method stub
		insuranceDao.deleteById(eid);
	}
	
	
	
	public double calculateInsuranceAmount(double price, int year) {
		int time=2019-year;
		int a=time*5;
		double price1= (price-(price*a/100));
		double ins=(price1*2.5/100);
		return ins;
	}

	@Override
	public Optional<InsuranceCalculatorEntity> viewInsuranceById(Integer id) {
		// TODO Auto-generated method stub
		return insuranceDao.findById(id);
	}

	@Override
	public List<InsuranceCalculatorEntity> viewAllInsurance() {
		// TODO Auto-generated method stub
		return insuranceDao.findAll();
	}

	

}
