$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/ramragup/Desktop/Testing/PaymentCardDetails/src/test/resources/payment/Payment.feature");
formatter.feature({
  "line": 1,
  "name": "PaymentDetails",
  "description": "",
  "id": "paymentdetails",
  "keyword": "Feature"
});
formatter.before({
  "duration": 15131656300,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Verify PaymentDetails page",
  "description": "",
  "id": "paymentdetails;verify-paymentdetails-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 7718105700,
  "status": "passed"
});
formatter.after({
  "duration": 1123643100,
  "status": "passed"
});
formatter.before({
  "duration": 9535405200,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Invalid first name",
  "description": "",
  "id": "paymentdetails;invalid-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user enters invalid first name",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "displays Please fill the first Name",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3623128100,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_first_name()"
});
formatter.result({
  "duration": 702880800,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.displays_Please_fill_the_first_Name()"
});
formatter.result({
  "duration": 2124973300,
  "status": "passed"
});
formatter.after({
  "duration": 730688900,
  "status": "passed"
});
formatter.before({
  "duration": 5561054300,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Invalid Email",
  "description": "",
  "id": "paymentdetails;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "user enters invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "display Please fill the Email",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 4063241600,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_email()"
});
formatter.result({
  "duration": 572529800,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_the_Email()"
});
formatter.result({
  "duration": 2046042800,
  "status": "passed"
});
formatter.after({
  "duration": 737255700,
  "status": "passed"
});
formatter.before({
  "duration": 2928550600,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Invalid Mobile Number",
  "description": "",
  "id": "paymentdetails;invalid-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "user does not enter mobileNumber",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "display Please fill Mobile No.",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 4262459900,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_does_not_enter_mobileNumber()"
});
formatter.result({
  "duration": 650082300,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_Mobile_No()"
});
formatter.result({
  "duration": 2029618100,
  "status": "passed"
});
formatter.after({
  "duration": 780835500,
  "status": "passed"
});
formatter.before({
  "duration": 10127725500,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Wrong Mobile Number",
  "description": "",
  "id": "paymentdetails;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user enters invalid mobileNumber",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display Please enter valid Mobile Number",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 4033718700,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_mobileNumber()"
});
formatter.result({
  "duration": 1143034800,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_enter_valid_Mobile_Number()"
});
formatter.result({
  "duration": 2025639800,
  "status": "passed"
});
formatter.after({
  "duration": 774147200,
  "status": "passed"
});
formatter.before({
  "duration": 1354470800,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Invalid Address",
  "description": "",
  "id": "paymentdetails;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user enters invalid Address",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "display Please fill Address",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3456493900,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_Address()"
});
formatter.result({
  "duration": 1229478400,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_Address()"
});
formatter.result({
  "duration": 2035456800,
  "status": "passed"
});
formatter.after({
  "duration": 830647300,
  "status": "passed"
});
formatter.before({
  "duration": 2543289400,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Invalid City",
  "description": "",
  "id": "paymentdetails;invalid-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "user enters invalid City",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "display Please fill City",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3436327700,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_City()"
});
formatter.result({
  "duration": 686067000,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_City()"
});
formatter.result({
  "duration": 25227000,
  "status": "passed"
});
formatter.after({
  "duration": 743405100,
  "status": "passed"
});
formatter.before({
  "duration": 3022366800,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "Invalid Zipcode",
  "description": "",
  "id": "paymentdetails;invalid-zipcode",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "user enters invalid Zipcode",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "display Please fill the Zipcode",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3163291200,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_Zipcode()"
});
formatter.result({
  "duration": 795538300,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_the_Zipcode()"
});
formatter.result({
  "duration": 32993000,
  "status": "passed"
});
formatter.after({
  "duration": 778024400,
  "status": "passed"
});
formatter.before({
  "duration": 2028844800,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "Invalid State",
  "description": "",
  "id": "paymentdetails;invalid-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 42,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "user enters invalid State",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "display Please fill the State",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3290302200,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_State()"
});
formatter.result({
  "duration": 927433600,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.display_Please_fill_the_State()"
});
formatter.result({
  "duration": 32476600,
  "status": "passed"
});
formatter.after({
  "duration": 760529500,
  "status": "passed"
});
formatter.before({
  "duration": 1893920500,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "Invalid CreditCard Number",
  "description": "",
  "id": "paymentdetails;invalid-creditcard-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 48,
  "name": "user enters invalid Creditcard Number",
  "keyword": "When "
});
formatter.step({
  "line": 49,
  "name": "displays Please fill the Credit card Number",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3445528600,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_invalid_Creditcard_Number()"
});
formatter.result({
  "duration": 954265400,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.displays_Please_fill_the_Credit_card_Number()"
});
formatter.result({
  "duration": 34201500,
  "status": "passed"
});
formatter.after({
  "duration": 745374800,
  "status": "passed"
});
formatter.before({
  "duration": 2402854000,
  "status": "passed"
});
formatter.scenario({
  "line": 51,
  "name": "Do not fill the Expired Year",
  "description": "",
  "id": "paymentdetails;do-not-fill-the-expired-year",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 52,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 53,
  "name": "user not enter Expired year",
  "keyword": "When "
});
formatter.step({
  "line": 54,
  "name": "displays Please fill the Expired year",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3210709200,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_not_enter_Expired_year()"
});
formatter.result({
  "duration": 1217370700,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.displays_Please_fill_the_Expired_year()"
});
formatter.result({
  "duration": 25347000,
  "status": "passed"
});
formatter.after({
  "duration": 733762000,
  "status": "passed"
});
formatter.before({
  "duration": 3124473100,
  "status": "passed"
});
formatter.scenario({
  "line": 56,
  "name": "Do not fill the CVV Number",
  "description": "",
  "id": "paymentdetails;do-not-fill-the-cvv-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 57,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 58,
  "name": "user not enter CVV Number",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "displays Please fill the CVV Number",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 2862152000,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_not_enter_CVV_Number()"
});
formatter.result({
  "duration": 1191320200,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.displays_Please_fill_the_CVV_Number()"
});
formatter.result({
  "duration": 32290100,
  "status": "passed"
});
formatter.after({
  "duration": 729433400,
  "status": "passed"
});
formatter.before({
  "duration": 3091111400,
  "status": "passed"
});
formatter.scenario({
  "line": 61,
  "name": "Valid Payment details",
  "description": "",
  "id": "paymentdetails;valid-payment-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 62,
  "name": "User is on PaymentDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "user enters valid  payment details",
  "keyword": "When "
});
formatter.step({
  "line": 64,
  "name": "displays SUCCESSFULLY SHIPPED",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_is_on_PaymentDetails_page()"
});
formatter.result({
  "duration": 3829245500,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.user_enters_valid_payment_details()"
});
formatter.result({
  "duration": 1380162900,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefinition.displays_SUCCESSFULLY_SHIPPED()"
});
formatter.result({
  "duration": 5290973900,
  "status": "passed"
});
formatter.after({
  "duration": 669260500,
  "status": "passed"
});
});