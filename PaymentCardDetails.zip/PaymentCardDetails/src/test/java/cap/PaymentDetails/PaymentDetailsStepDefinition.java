package cap.PaymentDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageaFactory.PaymentDetailPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefinition {
	
	WebDriver Driver;
	PaymentDetailPageFactory paymentDetail;
	
	 @Before
		public void setUp() {
			System.setProperty("webdriver.chrome.driver",
					 "C:\\Users\\ramragup\\Desktop\\Testing Documents\\chromedriver.exe");
			
			Driver= new ChromeDriver();
		}
	 @After
	    public void closee()
	    {
	        Driver.quit();
	    }
	
	
	@Given("^User is on PaymentDetails page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
		Driver.get("C:\\Users\\ramragup\\Desktop\\html pages\\payment-card-details.component.html");
		paymentDetail=new PaymentDetailPageFactory(Driver);
		Thread.sleep(2000);
		}
	
	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		  paymentDetail.setName("");
		  paymentDetail.setContinueBtn();
	   }

   @Then("^displays Please fill the first Name$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
		String name=Driver.findElement(By.id("fname")).getAttribute("validationMessage");
		Assert.assertEquals("Please fill out this field.", name);
		Thread.sleep(2000);
	}
   
   @When("^user enters invalid email$")
   public void user_enters_invalid_email() throws Throwable {
	      paymentDetail.setName("acbd");
	      paymentDetail.setMail("");
		  paymentDetail.setContinueBtn();
   }

   @Then("^display Please fill the Email$")
   public void display_Please_fill_the_Email() throws Throwable {
	   String mail=Driver.findElement(By.id("email")).getAttribute("validationMessage");
		Assert.assertEquals("Please fill out this field.", mail);
		Thread.sleep(2000);
   }
   
   
   @When("^user does not enter mobileNumber$")
   public void user_does_not_enter_mobileNumber() throws Throwable {
	      paymentDetail.setName("acbd");
	      paymentDetail.setMail("abcd@gmail.com");
	      paymentDetail.setMobileNo("");
		  paymentDetail.setContinueBtn();
   }

   @Then("^display Please fill Mobile No\\.$")
   public void display_Please_fill_Mobile_No() throws Throwable {
	   String mobileNo=Driver.findElement(By.id("mob")).getAttribute("validationMessage");
		Assert.assertEquals("Please fill out this field.", mobileNo);
		Thread.sleep(2000);
   }

   @When("^user enters invalid mobileNumber$")
   public void user_enters_invalid_mobileNumber() throws Throwable {
	      paymentDetail.setName("acbd");
	      paymentDetail.setMail("abcd@gmail.com");
	      paymentDetail.setMobileNo("5678901234");
		  paymentDetail.setContinueBtn();
   }
  
   @Then("^display Please enter valid Mobile Number$")
   public void display_Please_enter_valid_Mobile_Number() throws Throwable {
	   String mobileNo=Driver.findElement(By.id("mob")).getAttribute("validationMessage");
		Assert.assertEquals("Please match the requested format.", mobileNo);
		Thread.sleep(2000);
   }

@When("^user enters invalid Address$")
public void user_enters_invalid_Address() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("");
	  paymentDetail.setContinueBtn();
}

@Then("^display Please fill Address$")
public void display_Please_fill_Address() throws Throwable {
	 String address=Driver.findElement(By.id("adr")).getAttribute("validationMessage");
		Assert.assertEquals("Please fill out this field.", address);
		Thread.sleep(2000);
}

@When("^user enters invalid City$")
public void user_enters_invalid_City() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("");
	paymentDetail.setContinueBtn();
}

@Then("^display Please fill City$")
public void display_Please_fill_City() throws Throwable {
    String city=Driver.findElement(By.id("city")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.", city);
}

@When("^user enters invalid Zipcode$")
public void user_enters_invalid_Zipcode() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("");
	paymentDetail.setContinueBtn();
    
}

@Then("^display Please fill the Zipcode$")
public void display_Please_fill_the_Zipcode() throws Throwable {
	String zipcode=Driver.findElement(By.id("zip")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.", zipcode);
}

@When("^user enters invalid State$")
public void user_enters_invalid_State() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("");
	paymentDetail.setContinueBtn();
}

@Then("^display Please fill the State$")
public void display_Please_fill_the_State() throws Throwable {
	String state=Driver.findElement(By.id("state")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.", state);
}

@When("^user enters invalid cardholder name$")
public void user_enters_invalid_cardholder_name() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("TN");
    paymentDetail.setCardHolderName("");
    paymentDetail.setContinueBtn();
}

@Then("^displays Please fill the cardholder Name$")
public void displays_Please_fill_the_cardholder_Name() throws Throwable {
	String cardholderaName=Driver.findElement(By.id("cname")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.",cardholderaName );
}

@When("^user enters invalid Creditcard Number$")
public void user_enters_invalid_Creditcard_Number() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("TN");
    paymentDetail.setCardHolderName("Ragu");
    paymentDetail.setCardNo("");
    paymentDetail.setContinueBtn();
}

@Then("^displays Please fill the Credit card Number$")
public void displays_Please_fill_the_Credit_card_Number() throws Throwable {
	String cardNo=Driver.findElement(By.id("ccnum")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.",cardNo);
}

@When("^user not enter Expired year$")
public void user_not_enter_Expired_year() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("TN");
    paymentDetail.setCardHolderName("Ragu");
    paymentDetail.setCardNo("6578908012340765");
    paymentDetail.setExpmonth("March, 2020");
    paymentDetail.setExpyear("");
    paymentDetail.setContinueBtn();
}

@Then("^displays Please fill the Expired year$")
public void displays_Please_fill_the_Expired_year() throws Throwable {
	String ExpYear=Driver.findElement(By.id("expyear")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.",ExpYear);
}

@When("^user not enter CVV Number$")
public void user_not_enter_CVV_Number() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("TN");
    paymentDetail.setCardHolderName("Ragu");
    paymentDetail.setCardNo("6578908012340765");
    paymentDetail.setExpmonth("March, 2020");
    paymentDetail.setExpyear("2020");
    paymentDetail.setCvvNo("");
    paymentDetail.setContinueBtn(); 
}

@Then("^displays Please fill the CVV Number$")
public void displays_Please_fill_the_CVV_Number() throws Throwable {
	String CvvNo=Driver.findElement(By.id("cvv")).getAttribute("validationMessage");
    Assert.assertEquals("Please fill out this field.",CvvNo);
}
  
@When("^user enters valid  payment details$")
public void user_enters_valid_payment_details() throws Throwable {
	paymentDetail.setName("acbd");
    paymentDetail.setMail("abcd@gmail.com");
    paymentDetail.setMobileNo("9678901234");
    paymentDetail.setAddress("ngNagar");
    paymentDetail.setCity("cbe");
    paymentDetail.setZipcode("641402");
    paymentDetail.setState("TN");
    paymentDetail.setCardHolderName("Ragu");
    paymentDetail.setCardNo("6578908012340765");
    paymentDetail.setExpmonth("March,2020");
    paymentDetail.setExpyear("2020");
    paymentDetail.setCvvNo("352");
    paymentDetail.setContinueBtn(); 
}

@Then("^displays SUCCESSFULLY SHIPPED$")
public void displays_SUCCESSFULLY_SHIPPED() throws Throwable {
	 Driver.get("C:\\Users\\ramragup\\Desktop\\html pages\\success-page.component.html");
     Thread.sleep(5000);
     Driver.close();
} 



}
