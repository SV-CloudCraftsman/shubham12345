package PageaFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailPageFactory {
	WebDriver Driver;
	
	@FindBy(id="fname")
	@CacheLookup
	WebElement name;
	
	@FindBy(id="email")
	@CacheLookup
	WebElement mail;
	
	@FindBy(id="mob")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(id="adr")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="city")
	@CacheLookup
	WebElement city;

    @FindBy(id="zip")
	@CacheLookup
	WebElement zipcode;
    
    @FindBy(id="state")
	@CacheLookup
	WebElement state;
    
    @FindBy(id="cname")
	@CacheLookup
	WebElement cardHolderName;
    
    @FindBy(id="ccnum")
	@CacheLookup
	WebElement cardNo;
    
    @FindBy(id="expmonth")
	@CacheLookup
	WebElement expmonth;
    
    @FindBy(id="expyear")
   	@CacheLookup
   	WebElement expyear;
    
    @FindBy(id="cvv")
   	@CacheLookup
   	WebElement cvvNo;
    
    @FindBy(className="btn")
   	@CacheLookup
   	WebElement continueBtn;

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail.sendKeys(mail);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public WebElement getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo.sendKeys(cardNo);
	}

	public WebElement getExpmonth() {
		return expmonth;
	}

	public void setExpmonth(String expmonth) {
		this.expmonth.sendKeys(expmonth);
	}

	public WebElement getExpyear() {
		return expyear;
	}

	public void setExpyear(String expyear) {
		this.expyear.sendKeys(expyear);
	}

	public WebElement getCvvNo() {
		return cvvNo;
	}

	public void setCvvNo(String cvvNo) {
		this.cvvNo.sendKeys(cvvNo);
	}

	public WebElement getContinueBtn() {
		return continueBtn;
	}

	public void setContinueBtn() {
		this.continueBtn.click();
	}

	public PaymentDetailPageFactory(WebDriver driver) {
		
		this.Driver = driver;
		PageFactory.initElements(driver, this);
	 }

}