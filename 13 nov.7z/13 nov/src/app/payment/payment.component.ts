import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  router:Router;
  

  constructor(router:Router) { 
    this.router=router;
  }

  ngOnInit() {
  }

  redir(id:any)
  {
    if(id=="r1")
    {
      this.router.navigateByUrl('app-payment-card-details');
    }
    else
    if(id=="r2")
    {
      this.router.navigateByUrl('app-debit-card-details');

    }
  }
  

}