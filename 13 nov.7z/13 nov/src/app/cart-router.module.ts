import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{RouterModule,Routes} from '@angular/router';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { CODComponent } from './cod/cod.component';
import { SuccessPageComponent } from './success-page/success-page.component';
import { HomepageComponent } from './homepage/homepage.component';


const routes:Routes=[
  {
    path:'',
    component:HomepageComponent
  },
  {
    path:'app-add-to-cart',
    component:AddToCartComponent
  },
  {
    path:'app-wishlist',
    component:WishlistComponent
  },
  {
    path:'app-payment',
    component:PaymentComponent
  },
  {
    path:'app-payment-card-details',
    component:PaymentCardDetailsComponent
  },
  {
    path:'app-cod',
    component:CODComponent
  },
  {
    path:'app-success-page',
    component:SuccessPageComponent
  }
  

]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule],
})
export class CartRouterModule { }
