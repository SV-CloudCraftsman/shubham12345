import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProductServiceService, Products } from './product-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
//   title = 'Capstore20AugJEEFS';
//   router:Router;
//   service:ProductServiceService; // creating service object of ServiceService class 

//   constructor(service:ProductServiceService,router:Router) {
//     this.service=service;
//     this.router=router;
//    }

//    products:Products[]=[]
//   ngOnInit() {
//     // this.service.fetchProducts();
//     this.service.getProducts().subscribe(data=> this.products=data)
//   }

//   fetchProducts(productId)
//   {
//   this.service.fetchProducts(productId).then(response => {
//     this.products = response.result;
//     console.log(response.result);
//   }
  
//     , err => {
//       if (err.success != undefined && err.success == false) {
//         alert(err.errors);
//       }
//     });

// }
}
