import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductServiceService, Products } from '../product-service.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  router: Router;
  service: ProductServiceService; // creating service object of ServiceService class 

  constructor(service: ProductServiceService, router: Router) {
    this.service = service;
    this.router = router;
  }

  products: Products[] = []
  product:Products;
  ngOnInit() {
    // this.service.fetchProducts();
    this.service.getProducts().subscribe(data => this.products = data)
  }

  fetchProducts(productId) {
    this.service.fetchProducts(productId).then(response => {
      this.products = response.result;
      console.log(response.result);
    }

      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });

  }

  buyNow()
  {
    this.router.navigateByUrl('app-payment');
  }

  addToCart(productId)
  {
    alert(productId);
    this.service.addtocart(productId).then(response=>{
      this.addToCart=response.result;
      console.log(response.result);
    });
    this.router.navigateByUrl('app-add-to-cart');
  }

  addToWishlist()
  {
    this.router.navigateByUrl('app-wishlist');
  }

  // addtocart(productId:number)
  // {
  //   // let customerId=parseInt(sessionStorage.getItem('productId'))
  //   this.service.addtocart(productId).subscribe(data=>this.products);
    
  // }
}
