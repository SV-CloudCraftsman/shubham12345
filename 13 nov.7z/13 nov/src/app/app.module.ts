import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CartRouterModule } from './cart-router.module';
import { WishlistComponent } from './wishlist/wishlist.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { CODComponent } from './cod/cod.component';
import { SuccessPageComponent } from './success-page/success-page.component';
import { HomepageComponent } from './homepage/homepage.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    AddToCartComponent,
    WishlistComponent,
    PaymentComponent,
    PaymentCardDetailsComponent,
    CODComponent,
    SuccessPageComponent,
    HomepageComponent,
    
  ],
  imports: [
    BrowserModule,
    CartRouterModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
