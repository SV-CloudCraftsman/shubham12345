package com.cap.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="capstore_merchants")
public class Merchant  {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq_gen")
	@SequenceGenerator(name = "merchant_seq_gen", initialValue = 1000, sequenceName = "merchant_seq_gen")
	@Column
	private int merchant_Id;
	@Column
	private String merchantQue;
	@Column
	private String merchantAns;
	@Column
    private String userName;
	
	@Column(unique=true)
	@NotNull
	private String email;
	@Column
	private String password;
	@Column
	private String companyName;
	@Column
	private int mobNo;
	@Column
	private String address;
	@Column
	private long AadharNo;
	@Column
	private String merchant_status;
	
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Merchant [merchant_Id=" + merchant_Id + ", merchantQue=" + merchantQue + ", merchantAns=" + merchantAns
				+ ", merchant_status=" + merchant_status + ", userName=" + userName + ", email=" + email + ", password="
				+ password + ", Confirm_pass="  + ", companyName=" + companyName + ", mobNo=" + mobNo
				+ ", address=" + address + ", AadharNo=" + AadharNo + "]";
	}
	
	public Merchant(int merchant_Id, String merchantQue, String merchantAns, String merchant_status, String userName,
			String email, String password, String confirm_pass, String companyName, int mobNo, String address,
			long aadharNo) {
		super();
		this.merchant_Id = merchant_Id;
		this.merchantQue = merchantQue;
		this.merchantAns = merchantAns;
		this.merchant_status="inactive";
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.companyName = companyName;
		this.mobNo = mobNo;
		this.address = address;
		AadharNo = aadharNo;
	}
	
	public String getMerchantQue() {
		return merchantQue;
	}
	public void setMerchantQue(String merchantQue) {
		this.merchantQue = merchantQue;
	}
	public String getMerchantAns() {
		return merchantAns;
	}
	public void setMerchantAns(String merchantAns) {
		this.merchantAns = merchantAns;
	}
	
	public int getMerchant_Id() {
		return merchant_Id;
	}
	public void setMerchant_Id(int merchant_Id) {
		this.merchant_Id = merchant_Id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public String getMerchant_status() {
		return merchant_status;
	}
	public void setMerchant_status(String merchant_status1) {
		merchant_status1="inactive";
		merchant_status = merchant_status1;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getMobNo() {
		return mobNo;
	}
	public void setMobNo(int mobNo) {
		this.mobNo = mobNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAadharNo() {
		return AadharNo;
	}
	public void setAadharNo(long aadharNo) {
		AadharNo = aadharNo;
	}
	

	
}
