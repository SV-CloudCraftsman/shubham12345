package com.cap;

import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cap.service.CustomerServiceImpl;
import com.cap.service.Customerservice;

@SpringBootApplication
public class SamplePpApplication {

	public static void main(String[] args) throws SQLException {
		SpringApplication.run(SamplePpApplication.class, args);
		
	}
	
	

}
