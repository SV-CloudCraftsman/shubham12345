package com.cap.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CartRepo;
import com.cap.dao.CustomerRepo;
import com.cap.dao.MerchantRepo;
import com.cap.dao.OrderRepo;
import com.cap.dao.ProductRepo;
import com.cap.dao.WishListRepo;
import com.cap.entities.AddToCartProduct;
import com.cap.entities.Order;
import com.cap.entities.Product;
import com.cap.entities.WishListToCartProduct;

import oracle.sql.DATE;

@Service
public class CustomerServiceImpl implements Customerservice {
	@Autowired
	CustomerRepo customerRepo;
	@Autowired
	MerchantRepo merchantRepo;
	@Autowired
	ProductRepo productRepo;
	@Autowired
	CartRepo cartRepo;
	@Autowired
	WishListRepo wishRepo;

	@Autowired
	OrderRepo orderRepo;

	@Override
	public Product fetchProduct(int productId) {
		// TODO Auto-generated method stub
		return productRepo.findById(productId);
	}

	@Override
	public List<Product> addProducts(Product product) {
		// TODO Auto-generated method stub
		productRepo.save(product);
		return productRepo.findAll();
	}

	@Override
	public AddToCartProduct addToCart(int productId) {
		// TODO Auto-generated method stub
		AddToCartProduct add = new AddToCartProduct();
		Product p = productRepo.findById(productId);
		add.setProductQty(1);
		add.setProductId(p.getProductId());
		add.setProductName(p.getProductName());
		add.setProductPrice(p.getProductPrice());
		return cartRepo.save(add);

	}

	@Override
	public WishListToCartProduct addtowishlist(int productId) {
		WishListToCartProduct wish = new WishListToCartProduct();
		Product pro = productRepo.findById(productId);
		wish.setProductQty(1);
		wish.setProductId(pro.getProductId());
		wish.setProductName(pro.getProductName());
		wish.setProductPrice(pro.getProductPrice());

		return wishRepo.save(wish);
	}

	@Override
	public Order buyNow(int productId) throws SQLException {
		// TODO Auto-generated method stu
		Order order = new Order();
		System.out.println("hello");
		AddToCartProduct cart = cartRepo.findById(productId).get();
		System.out.println("cartRepo" + cartRepo.toString());
		System.out.println(cart);
		// AddToCartProduct cart = cartRepo.findOrder(productId);
		order.setProductId(productId);
		order.setProductName(cart.getProductName());
		order.setProductPrice(cart.getProductPrice());
		order.setProductQty(cart.getProductQty());
		order.setTotalAmount(cart.getProductPrice() * cart.getProductQty());
		order.setProductMode("debit");
	    orderRepo.save(order);
	    cartRepo.deleteById(productId);
	    return orderRepo.save(order);
	}

	@Override
	public List<Product> fetchAll() {
		// TODO Auto-generated method stub
		return productRepo.findAll();
	}

}
