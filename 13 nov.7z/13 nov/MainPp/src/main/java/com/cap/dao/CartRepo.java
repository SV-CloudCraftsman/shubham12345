package com.cap.dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.entities.AddToCartProduct;

@Repository
public interface CartRepo extends JpaRepository<AddToCartProduct, Integer> {
	
	@Query("select p1 from AddToCartProduct p1 where p1.cartId=:cid")
	public AddToCartProduct findOrder(@Param("cid") long cartId);

}
