package com.cap.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.entities.WishListToCartProduct;

@Service

public interface MerchantService  {
	public List<Merchant> addMerchant(Merchant merchant);

	public List<Product> addProduct(Product product);
	 
	public List<AddToCartProduct> addCarts(AddToCartProduct addCarts);
	
	public List<WishListToCartProduct> addWishListCarts(WishListToCartProduct wishListCarts);
	

}
