package com.cap.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.entities.Order;

public interface OrderRepo extends JpaRepository<Order, Integer> {
	






}
