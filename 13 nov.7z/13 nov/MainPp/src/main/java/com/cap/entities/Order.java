package com.cap.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import oracle.sql.DATE;

@Entity
@Table(name = "capstore_orders")
public class Order {

	@Id
	@GeneratedValue
	@Column(length = 20)
	private int order_Id;

	@Column
	private int productId;

	@Column
	private String productName;
	
	@Column
	private double productPrice;
	
	@Column
	private int productQty;
	
	@Column
	private String productMode;


	@Column(length = 20)
	private double totalAmount;

	@ManyToOne
	@JoinColumn
	private Product product;

	@ManyToOne
	@JoinColumn(name = "email")
	private Merchant merchant;

	



	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}

	public String getProductMode() {
		return productMode;
	}

	public void setProductMode(String productMode) {
		this.productMode = productMode;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	


	public int getOrder_Id() {
		return order_Id;
	}

	public void setOrder_Id(int order_Id) {
		this.order_Id = order_Id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	

	public Order(int order_Id, int productId, String productName, double productPrice, int productQty,
			String productMode, double totalAmount, Product product, Merchant merchant) {
		super();
		this.order_Id = order_Id;
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQty = productQty;
		this.productMode = productMode;
		this.totalAmount = totalAmount;
		this.product = product;
		this.merchant = merchant;
	}

	public Order() {
		// TODO Auto-generated constructor stub
	}
	
}
