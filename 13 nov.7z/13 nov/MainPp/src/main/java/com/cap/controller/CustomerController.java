package com.cap.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Order;
import com.cap.entities.Product;
import com.cap.entities.WishListToCartProduct;
import com.cap.service.Customerservice;
import com.cap.service.MerchantService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(origins="*")
public class CustomerController {
	
	@Autowired
	Customerservice service;
	
	@GetMapping("/fetchProduct/{productId}")
	public Product fetchProduct(@PathVariable int productId) {
	return	service.fetchProduct(productId);
	}
	
	@PostMapping("/addProduct")
	public List<Product> addProducts(@RequestBody Product product) {
		return service.addProducts(product);
	}
	
	@PostMapping("/addToCart/{productId}")
	public AddToCartProduct addToCart(@PathVariable int productId)
	{
		return service.addToCart(productId);
		
	}
	
	@PostMapping("/addToWishList/{productId}")
	public WishListToCartProduct addtowishlist(@PathVariable int productId) 
	{
		return service.addtowishlist(productId);
		
	}
	
	@PutMapping("/buyNow/{productId}")
	public Order buyNow(@PathVariable int productId) throws SQLException
	{
		return service.buyNow(productId);
		
	}
	
	@GetMapping("/fetchAll")
	public List<Product> fetchAll()
	{
		return service.fetchAll();
	}
	

}
