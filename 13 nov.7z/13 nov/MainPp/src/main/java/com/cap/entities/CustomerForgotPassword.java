package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_forgotpass")
public class CustomerForgotPassword {
    
    @Id
    @Column(length=20)
    private String email;
    
    @Column(length=20)
    private String newPass;
    
    @Column(length=20)
    private String conPass;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNewPass() {
		return newPass;
	}

	public void setNewPass(String newPass) {
		this.newPass = newPass;
	}

	public String getConPass() {
		return conPass;
	}

	public void setConPass(String conPass) {
		this.conPass = conPass;
	}
    
   public CustomerForgotPassword() {
	// TODO Auto-generated constructor stub
}

public CustomerForgotPassword(String email, String newPass, String conPass) {
	super();
	this.email = email;
	this.newPass = newPass;
	this.conPass = conPass;
}

@Override
public String toString() {
	return "CustomerForgotPassword [email=" + email + ", newPass=" + newPass + ", conPass=" + conPass + "]";
}
   

    
    
    
    
    
}