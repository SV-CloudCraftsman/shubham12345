package factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginFactory {
	
	WebDriver driver;
	
		@FindBy(name="userName")
		@CacheLookup
		WebElement userName;

		@FindBy(id="userErrMsg")
		WebElement usernameError;
		
		
		//using how class
		@FindBy(name="userPwd")
		@CacheLookup
		WebElement password;
				
				
		@FindBy(id="pwdErrMsg")
		WebElement passwordError;


		public WebElement getUserName() {
			return userName;
		}


		public void setUserName(String userName) {
			this.userName.sendKeys(userName);;
		}


		public String getUsernameError() {
			return usernameError.getText();
		}


		public void setUsernameError(WebElement usernameError) {
			this.usernameError = usernameError;
		}


		public WebElement getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password.sendKeys(password);;
		}


		public WebElement getPasswordError() {
			return passwordError;
		}


		public void setPasswordError(WebElement passwordError) {
			this.passwordError = passwordError;
		}


		public WebElement getLoginButton() {
			return loginButton;
		}


		public void setLoginButton() {
			this.loginButton.click();
		}


		@FindBy(className="btn")
		@CacheLookup
		WebElement loginButton;

		
		//initiating the elements
		public LoginFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	
		

}
