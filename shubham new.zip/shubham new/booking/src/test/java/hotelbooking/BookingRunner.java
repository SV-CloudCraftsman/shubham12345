package hotelbooking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\shubham\\booking\\src\\test\\resources\\booking.feature"},
		glue= {"hotelbooking"},
		dryRun=false,
		strict=true,
		monochrome=true,
		format= {"pretty" , "html: test-output"}
		
		)


public class BookingRunner {

}
