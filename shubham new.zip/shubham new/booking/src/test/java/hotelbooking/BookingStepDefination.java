package hotelbooking;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factory.BookingPageFactory;
import junit.framework.Assert;

public class BookingStepDefination {
	public WebDriver driver;
	public BookingPageFactory factory;
	
	
	@Given("^user is on Hotel Booking page$")
	public void user_is_on_Hotel_Booking_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shuvishw\\Desktop\\Chrome\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("C:\\Users\\shuvishw\\Desktop\\BDDCaseStudyFinal\\hotelbooking.html");
	    factory=new BookingPageFactory(driver);
	    
	}

	@Then("^verify the heading as Hotel Booking Form$")
	public void verify_the_heading_as_Hotel_Booking_Form() throws InterruptedException {
		Thread.sleep(3000);
		String headingText=driver.findElement(By.tagName("h2")).getText();
		Assert.assertEquals("Hotel Booking Form", headingText);
		driver.close();
	}

	@When("^user left the First Name field empty$")
	public void user_left_the_First_Name_field_empty() throws InterruptedException{
		Thread.sleep(3000);
		factory.setFirstName("");
		
	}

	@Then("^click on Confirm Booking button$")
	public void click_on_Confirm_Booking_button() {
		factory.setConfirmButton();
	}

	@Then("^it will pop-up the alert box displays the message “Please fill the First Name”$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_First_Name() throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
	}
	
	@When("^user left the Last Name field empty$")
	public void user_left_the_Last_Name_field_empty() throws InterruptedException {
		Thread.sleep(3000);
		factory.setFirstName("shubham");
		Thread.sleep(3000);
		factory.setLastName("");
		Thread.sleep(3000);
	}

	@Then("^it will pop-up the alert box displays the message “Please fill the Last Name”$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Last_Name() throws InterruptedException {
		Thread.sleep(3000);
		String expectedMessage1="Please fill the Last Name";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.close();
		
	}
	
	@When("^user gives wrong email format$")
	public void user_gives_wrong_email_format() throws InterruptedException {
		factory.setFirstName("shubham");
		Thread.sleep(3000);
		factory.setLastName("Vishwakarma");
		factory.setEmail("shubham@capgemini.com");
		String email=factory.getEmail();
		
		if(email.endsWith("@capgemini.com"))
		{
			System.out.println("Valid email ID");
		
			
		}else
		{
			Thread.sleep(3000);
			System.out.println("Incorrect pattern");
			
		}
		
		
	}

	
	@Then("^it will pop-up the alert box displays the message “Please enter valid Email Id\\.”$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_enter_valid_Email_Id() throws InterruptedException {
		
		
		//driver.switchTo().alert().accept();
		
		
		
		driver.switchTo().alert().accept();
		
		Thread.sleep(3000);
		driver.close();
		
	}


	

}
