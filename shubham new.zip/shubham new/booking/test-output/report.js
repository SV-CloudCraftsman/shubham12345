$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/shubham/booking/src/test/resources/booking.feature");
formatter.feature({
  "line": 1,
  "name": "Validating Hotel Booking Form",
  "description": "",
  "id": "validating-hotel-booking-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Verify the title “Hotel Booking” of the page",
  "description": "",
  "id": "validating-hotel-booking-form;verify-the-title-“hotel-booking”-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "verify the heading as Hotel Booking Form",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 2597282000,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.verify_the_heading_as_Hotel_Booking_Form()"
});
formatter.result({
  "duration": 3206922600,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "the alert box displays the message “Please fill the First Name” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-first-name”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user left the First Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "it will pop-up the alert box displays the message “Please fill the First Name”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1360890600,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_First_Name_field_empty()"
});
formatter.result({
  "duration": 3074229700,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 63933400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_First_Name()"
});
formatter.result({
  "duration": 9254900000,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "the alert box displays the message “Please fill the Last Name” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-last-name”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user left the Last Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "it will pop-up the alert box displays the message “Please fill the Last Name”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1514292300,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_Last_Name_field_empty()"
});
formatter.result({
  "duration": 9148234400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 70854700,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 9185327800,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "the alert box will pop a message \"Please fill the email\" upon wrong email format entered in text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-will-pop-a-message-\"please-fill-the-email\"-upon-wrong-email-format-entered-in-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "user gives wrong email format",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "it will pop-up the alert box displays the message “Please enter valid Email Id.”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1392448800,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_gives_wrong_email_format()"
});
formatter.result({
  "duration": 6339881000,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 60734500,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_enter_valid_Email_Id()"
});
formatter.result({
  "duration": 3207409900,
  "status": "passed"
});
});