import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { AddEmployeesComponent } from './add-employees/add-employees.component';
import { AppRoutingModule } from './app-routing.module';
import { ServiceService } from './service.service';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { CodComponent } from './cod/cod.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { SuccessPageComponent } from './success-page/success-page.component';
import { WishlistComponent } from './wishlist/wishlist.component';

@NgModule({
  declarations: [
    AppComponent,
    ListEmployeesComponent,
    AddEmployeesComponent,
    AddToCartComponent,
    CodComponent,
    PaymentComponent,
    PaymentCardDetailsComponent,
    SuccessPageComponent,
    WishlistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
