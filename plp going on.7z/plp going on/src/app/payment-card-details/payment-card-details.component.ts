import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment-card-details',
  templateUrl: './payment-card-details.component.html',
  styleUrls: ['./payment-card-details.component.css']
})
export class PaymentCardDetailsComponent implements OnInit {

  router:Router;
  constructor(router:Router) { 
    this.router=router;
  }

  ngOnInit() {
  }

  address()
  {
    this.router.navigateByUrl('address');

  }
}
