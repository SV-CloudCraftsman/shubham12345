import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';

@Injectable()
export class ServiceService {
http:HttpClient;
route:Router;
products:Products[]=[];
  constructor(http:HttpClient) 
  { 
    this.http=http;
  }

  fetched:boolean=false;
  // fetchEmployees() will fetch the data from database.json file
  fetchProducts()
  {
    this.http.get('./assets/database.json')
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }
      }
    )
  }


  // getEmployees() will fetch the employees from Employee array
  getProducts():Products[]{
    return this.products;
  }


  // conversion of data
  convert(data1:any)
  {
    for(let o of data1){
      let e=new Products(o.id,o.image,o.name,o.type,o.price,o.description,o.availability,o.mername);
      this.products.push(e);

    }
  }


  // delete the data from table
  delete(eid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.products.length;i++){
      let e=this.products[i];
      if(eid==e.id)
      {
        foundIndex=i;
        break;
      }
    }
    this.products.splice(foundIndex,1);
  }


  // this function will add the employee info to employee array
  addProducts(e:Products)
  {
    this.products.push(e);
  }
}


// class Employee
export class Products
{
  id:number;
  image:any;
  name:string;
  type:string;
  price:number;
  description:string;
  availability:number;
  mername:string;
  constructor(id:number,image:any,name:string,type:string,price:number,description:string,availability:number,mername:string)
  {
    this.id=id;
    this.image=image;
    this.name=name;
    this.type=type;
    this.price=price;
    this.description=description;
    this.availability=availability;
    this.mername=mername;
  }
}