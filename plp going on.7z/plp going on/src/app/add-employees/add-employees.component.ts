import { Component, OnInit } from '@angular/core';
import { Products, ServiceService } from '../service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-add-employees',
  templateUrl: './add-employees.component.html',
  styleUrls: ['./add-employees.component.css']
})
export class AddEmployeesComponent implements OnInit {

  router:Router;
  

  createdEmployee:Products;
  createdFlag:boolean=false;
  service:ServiceService;
  constructor(service:ServiceService,router:Router)
  {
    this.service=service;
    this.router=router;
  }



  // adding employee data to employees array
  addEmployee(o:any)
  {
    this.createdEmployee=new Products(o.id,o.image,o.name,o.type,o.price,o.description,o.availability,o.mername);
    this.service.addProducts(this.createdEmployee);
    this.router.navigateByUrl('');
  }


  ngOnInit() {
  }

}
