import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cod',
  templateUrl: './cod.component.html',
  styleUrls: ['./cod.component.css']
})
export class CodComponent implements OnInit {


  router:Router;

  constructor(router:Router) {
    this.router=router;
   }

  ngOnInit() {
  }

  success(){

    this.router.navigateByUrl('success');
  }
}
