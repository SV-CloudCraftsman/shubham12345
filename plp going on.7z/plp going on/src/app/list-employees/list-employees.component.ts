import { Component, OnInit } from '@angular/core';
import { ServiceService,Products } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  router:Router;
  service:ServiceService; // creating service object of ServiceService class 
  constructor(service:ServiceService,router:Router)
  {
    this.service=service;
    this.router=router;
  }

  products:Products[]=[]
  ngOnInit() {
    this.service.fetchProducts();
    this.products=this.service.getProducts();
  }

  // calling the delete method from service 
  delete(eid:number)
  {
    this.service.delete(eid);
  }

  buynow()
  {
    this.router.navigateByUrl('app-add-to-cart');
  }

}
