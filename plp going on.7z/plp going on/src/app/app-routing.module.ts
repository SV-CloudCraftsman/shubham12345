import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { AddEmployeesComponent } from './add-employees/add-employees.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentCardDetailsComponent } from './payment-card-details/payment-card-details.component';
import { CodComponent } from './cod/cod.component';
import { SuccessPageComponent } from './success-page/success-page.component';


const routes:Routes=[
  {
    path:'add-employee',
    component:AddEmployeesComponent
  },
  {
    path:'',
    component:ListEmployeesComponent
  },
  {
    path:'app-add-to-cart',
    component:AddToCartComponent
  },
  {
    path:'app-payment',
    component:PaymentComponent
  },
  {
    path:'app-payment-card-details',
    component:PaymentCardDetailsComponent
  },
  {
    path:'address',
    component:CodComponent
  },
  {
    path:'success',
    component:SuccessPageComponent
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
