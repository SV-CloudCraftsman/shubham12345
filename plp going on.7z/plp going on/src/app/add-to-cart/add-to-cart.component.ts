import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit {

  router:Router
  service:ServiceService; // creating service object of ServiceService class 
  constructor(service:ServiceService,router:Router)
  {
    this.service=service;
    this.router=router;
  }

  addtocart()
  {
    this.router.navigateByUrl('app-payment');
  }

  ngOnInit() {
  }

}
