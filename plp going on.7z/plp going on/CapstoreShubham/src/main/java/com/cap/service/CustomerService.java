package com.cap.service;

import java.util.List;

import com.cap.beans.Products;

public interface CustomerService {

	public List<Products> addProducts(Products product);

	public Products productDetails(int productId);


}
