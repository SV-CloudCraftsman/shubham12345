package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.beans.Products;
import com.cap.dao.CartDao;
import com.cap.dao.OrderDao;
import com.cap.dao.ProductsDao;
import com.cap.dao.WishlistDao;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	ProductsDao productsDao;
	
	@Autowired
	OrderDao orderDao;
	
	@Autowired
	CartDao cartDao;
	
	@Autowired
	WishlistDao wishlistDao;
	
	@Override
	public List<Products> addProducts(Products product) {
		// TODO Auto-generated method stub
		productsDao.save(product);
		return productsDao.findAll();
	}

	@Override
	public Products productDetails(int productId) {
		// TODO Auto-generated method stub
		return productsDao.findById(productId).get();
	}
	

}
