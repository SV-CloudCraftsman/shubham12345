package com.cap.beans;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_order")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_seq_gen")
	@SequenceGenerator(name = "order_seq_gen", initialValue = 10000, sequenceName = "order_seq")
	private int orderId;
	private int quantity;
	private double totalAmount;
	@ManyToOne(fetch = FetchType.LAZY)
	private Products product;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Products getProduct() {
		return product;
	}

	public void setProduct(Products product) {
		this.product = product;
	}

	public Order(int orderId, int quantity, double totalAmount, Products product) {
		super();
		this.orderId = orderId;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
		this.product = product;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", quantity=" + quantity + ", totalAmount=" + totalAmount + ", product="
				+ product + "]";
	}

	public Order() {
		// TODO Auto-generated constructor stub
	}

}
