package com.cap.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_wishlist")
public class Wishlist {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wishlist_seq_gen")
	@SequenceGenerator(name = "wishlist_seq_gen", initialValue = 10000, sequenceName = "wishlist_seq")
	private int wishlistId;
	@ManyToMany(fetch = FetchType.LAZY)
	private List<Products> products;

	public int getWishlistId() {
		return wishlistId;
	}

	public void setWishlistId(int wishlistId) {
		this.wishlistId = wishlistId;
	}

	public List<Products> getProducts() {
		return products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}

	public Wishlist(int wishlistId, List<Products> products) {
		super();
		this.wishlistId = wishlistId;
		this.products = products;
	}

	@Override
	public String toString() {
		return "Wishlist [wishlistId=" + wishlistId + ", products=" + products + "]";
	}

	public Wishlist() {
		// TODO Auto-generated constructor stub
	}

}
