package com.cap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoreShubhamApplicationTests {

	@Test
	void contextLoads() {
	}

}
