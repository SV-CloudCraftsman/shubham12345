import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TrackOperationComponent } from './track-operation.component';



describe('TrackOperationComponent', () => {
  let component: TrackOperationComponent;
  let fixture: ComponentFixture<TrackOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackOperationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
