import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllPlacedProductsComponent } from './all-placed-products.component';

describe('AllPlacedProductsComponent', () => {
  let component: AllPlacedProductsComponent;
  let fixture: ComponentFixture<AllPlacedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllPlacedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllPlacedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
