import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductTrackingStatusOperationComponent } from './product-tracking-status-operation.component';

describe('ProductTrackingStatusOperationComponent', () => {
  let component: ProductTrackingStatusOperationComponent;
  let fixture: ComponentFixture<ProductTrackingStatusOperationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductTrackingStatusOperationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductTrackingStatusOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
