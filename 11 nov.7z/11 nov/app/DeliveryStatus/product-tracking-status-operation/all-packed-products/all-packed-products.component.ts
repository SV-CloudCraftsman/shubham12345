import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';


@Component({
  selector: 'app-all-packed-products',
  templateUrl: './all-packed-products.component.html',
  styleUrls: ['./all-packed-products.component.css']
})
export class AllPackedProductsComponent implements OnInit {

  service: AdminServiceService;
  constructor(service: AdminServiceService) { this.service = service }
  response: any;
  ngOnInit() {
    this.fetchDeliveryStatus();

  }
  fetchDeliveryStatus() {
    this.service.fetchDeliveryStatus('packed').then(response => {
    this.response = response.result;
      console.log(response);
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  changeStatus(id)
  {
    this.service.updateDeliveryStatus(id,'shipped').then(response => {
      window.location.reload();
      }
        , err => {
          if (err.success != undefined && err.success == false) {
            alert(err.errors);
          }
        });
  }
}
