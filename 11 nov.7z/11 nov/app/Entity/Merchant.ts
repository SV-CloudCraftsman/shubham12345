export class Merchant{
    merchantId:number;
    merchantAnswer:string;
    merchantCompanyName:string;
    merchantContactNo:string;
    merchantDiscount:number;
    merchantGSTNo:string;
    merchantName:string;
    merchantPassword:string;
    merchantQuestion:number;
    merchantStatus:number
  
      
          constructor(  merchantId:number,merchantAnswer:string,merchantCompanyName:string,merchantContactNo:string,merchantDiscount:number,merchantGSTNo:string,merchantName:string,merchantPassword:string, merchantQuestion:number,merchantStatus:number)
          {
            this.merchantId=merchantId;
            this.merchantAnswer=merchantAnswer;
            this.merchantCompanyName=merchantCompanyName;
            this.merchantContactNo=merchantContactNo;
            this.merchantDiscount=merchantDiscount;
            this.merchantGSTNo=merchantGSTNo;
            this.merchantName=merchantName;
            this.merchantPassword=merchantPassword;
            this.merchantQuestion=merchantQuestion;
            this.merchantStatus=merchantStatus;
          }
      }