export class Data{
    productId:number;
    productName:String;
    productDescription:String;
    productQuantity:number;
    productPrice:number;
      constructor(productId:number,productName:String, productDescription:String,productQuantity:number, productPrice:number)
      {
        this.productId=productId;
        this.productName=productName;
        this.productDescription=productDescription;
        this.productQuantity=productQuantity;
        this. productPrice= productPrice;
       
      }
    }