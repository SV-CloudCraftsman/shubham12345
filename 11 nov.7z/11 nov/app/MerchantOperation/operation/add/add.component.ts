import { Component, OnInit } from '@angular/core';

import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  addMerchant(data:any) {
    let merchant = new Merchant(data.merchantId,data.merchantAnswer,data.merchantCompanyName,data.merchantContactNo,data.merchantDiscount,data.merchantGSTNo,data.merchantName,data.merchantPassword,data.merchantQuestion,data.merchantStatus);
    this.service.addMerchant(merchant).then(response => {
      if(response.success == true)
      {
        alert("Merchant added successfully, Merchant id is "+response.result.merchantId);
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
