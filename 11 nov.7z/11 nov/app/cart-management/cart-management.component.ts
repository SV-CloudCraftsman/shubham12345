import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../Service/admin-service.service';

@Component({
  selector: 'app-cart-management',
  templateUrl: './cart-management.component.html',
  styleUrls: ['./cart-management.component.css']
})
export class CartManagementComponent implements OnInit {
  title = 'plp';
  constructor(private service: AdminServiceService) { }

  ngOnInit() {
  }
  onSubmit(value) {
    this.service.changeCartMinimumValue(value.minValue).then(response => {
      if (response.success == true) {
        alert(response.result);
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
