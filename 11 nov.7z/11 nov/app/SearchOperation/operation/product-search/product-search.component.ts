import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Product } from 'src/app/Entity/Product';



@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
service:AdminServiceService;
  constructor(service:AdminServiceService) 
  {
    this.service=service;
   }
   ngOnInit()
   {
     
   }
   product:Product[]=[];
   searchProduct(data:any){
    this.service.searchByProductName(data.productName).then(response => {
      this.product = response.result;
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
