import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  url: string = "http://localhost:9676/admin";
  constructor(private http: HttpClient) {
  }
  private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
  //Delivery Status
  fetchDeliveryStatus(type: string): Promise<any> {
    return this.http.get(this.url + '/deliverystatus/' + type)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  //merchant
  getAllMerchants(): Promise<any> {
    return this.http.get(this.url + '/merchant/all')
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  addMerchant(merchant): Promise<any> {
    return this.http.post(this.url + '/merchant/add', merchant)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
      
  }
  deleteMerchant(merchantId:number): Promise<any> {
    return this.http.delete(this.url + '/merchant/'+merchantId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  //third party merchant
  getAllThirdPartyMerchants(): Promise<any> {
    return this.http.get(this.url + '/merchant/others/all')
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  addThirdPartyMerchant(merchant): Promise<any> {
    return this.http.post(this.url + '/merchant/others/add', merchant)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  deleteThirdPartyMerchant(id: number): Promise<any> {
    return this.http.delete(this.url + '/merchant/others/' + id)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  //Merchant Feedback
  getMerchantFeedbacks(status: string): Promise<any> {
    return this.http.get(this.url + '/merchantfeedback/' + status)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  changeMerchantFeedbackStatus(merchantFeedback): Promise<any> {
    return this.http.put(this.url + '/merchantfeedback', merchantFeedback)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  //Product
  addProduct(product): Promise<any> {
    return this.http.post(this.url + '/product/add', product)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getAllProducts(): Promise<any> {
    return this.http.get(this.url + '/product/all')
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getproductById(productId: number): Promise<any> {
    return this.http.get(this.url + '/product/' + productId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  deleteProduct(productId): Promise<any> {
    return this.http.delete(this.url +'/product/'+ productId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getproductByCategoryId(categoryId: number): Promise<any> {
    return this.http.get(this.url + '/category/product/' + categoryId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getproductByMerchantId(merchantId: number): Promise<any> {
    return this.http.get(this.url + '/merchant/product/' + merchantId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getproductByThirdPartyMerchantId(merchantId: number): Promise<any> {
    return this.http.get(this.url + '/merchant/others/product/' + merchantId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  updateStock(product): Promise<any> {
    return this.http.put(this.url + '/stock', product)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  //search

  searchByProductName(productName): Promise<any> {
    return this.http.get(this.url + '/product/search/'+productName)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  searchByCustomerName(customerName): Promise<any> {
    return this.http.get(this.url + '/customer/search/'+customerName)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  searchByMerchantName(merchantName): Promise<any> {
    return this.http.get(this.url + "/merchant/search/"+merchantName)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  //coupon
  getAllCoupons(): Promise<any> {
    return this.http.get(this.url + '/coupon/all')
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  addCoupon(coupon): Promise<any> {
    return this.http.post(this.url + '/coupon/add', coupon)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  updateCoupon(coupon): Promise<any> {
    return this.http.put(this.url + '/coupon', coupon)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  deleteCoupon(id: number): Promise<any> {
    return this.http.delete(this.url + '/coupon/' + id)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  //delivery status

  changeStatus(id) {
    let data = {
      id: id
    };
    return this.http.put(this.url + '/delivery/update', data)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getAllDeliveryStatus(statusCode): Promise<any> {
    return this.http.get(this.url + '/deliverystatus/' + statusCode)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  updateDeliveryStatus(id, statusCode): Promise<any> {
    return this.http.put(this.url + '/deliverystatus/' + id + '/' + statusCode, {})
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }

  //Category
  addCategory(category): Promise<any> {
    return this.http.post(this.url + '/category/add', category)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  getAllCategories(): Promise<any> {
    return this.http.get(this.url + '/category/all')
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
  deleteCategory(categoryId): Promise<any> {
    return this.http.delete(this.url + '/category/'+categoryId)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }


  //Cart Management
  changeCartMinimumValue(value: number): Promise<any> {
    return this.http.put(this.url + '/cart/' + value, {})
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
  }
}
