import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  service: AdminServiceService;
  category: Category[] = [];
  constructor(service: AdminServiceService) {
    this.service = service;
    this.getAllCategories();
  }
  ngOnInit() {
    
  }
  getAllCategories() {
    this.service.getAllCategories().then(response => {
      this.category = response.result;
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
  deleteCategory(categoryId: number) {
   
    this.service.deleteCategory(categoryId).then(response => {
      if(response.result == true)
      {
     alert("Category deleted successfully");
      }
    this.getAllCategories();
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
