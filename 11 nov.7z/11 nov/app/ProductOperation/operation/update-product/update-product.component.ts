import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {

  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
   updateStock(data:any) {
    let createdProduct=new Product(data.productId,data.productDescription,data.productDiscount,data.productName,data.productPrice,data.productQuantity);
    this.service.updateStock(createdProduct).then(response => {
      if (response.success == true) {
        alert("Stock updated successfully");
      }
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
        }
      });
  }
}
