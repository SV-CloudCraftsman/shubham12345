import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InteractionComponent } from './Interaction/interaction/interaction.component';
import { HomepageComponent } from './MerchantOperation/homepage/homepage/homepage.component';
import { AddComponent } from './MerchantOperation/operation/add/add.component';
import { ShowComponent } from './MerchantOperation/operation/show/show.component';
import { AdminCouponComponent } from './Coupon/admin-coupon/admin-coupon.component';
import { FrontPageComponent } from './ProductOperation/FrontPage/front-page/front-page.component';
import { ProductComponent } from './ProductOperation/operation/product/product.component';
import { AddProductComponent } from './ProductOperation/operation/add-product/add-product.component';
import { UpdateProductComponent } from './ProductOperation/operation/update-product/update-product.component';
import { CategoryComponent } from './ProductOperation/operation/category/category.component';
import { AddCategoryComponent } from './ProductOperation/operation/add-category/add-category.component';
import { FirstPageComponent } from './SearchOperation/FirstPage/first-page/first-page.component';
import { CustomerSearchComponent } from './SearchOperation/operation/customer-search/customer-search.component';
import { MerchantSearchComponent } from './SearchOperation/operation/merchant-search/merchant-search.component';
import { ProductSearchComponent } from './SearchOperation/operation/product-search/product-search.component';
import { FeedpageComponent } from './FeedBack/FeedPage/feedpage/feedpage.component';
import { FeedbackComponent } from './FeedBack/operation/feedback/feedback.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { ForwardComponent } from './FeedBack/operation/forward/forward.component';
import { NotForwardComponent } from './FeedBack/operation/not-forward/not-forward.component';
import { TrackOperationComponent } from './DeliveryStatus/track-operation/track-operation.component';
import { AllCancelledProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-cancelled-products/all-cancelled-products.component';
import { AllDeliveredProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-delivered-products/all-delivered-products.component';
import { AllPackedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-packed-products/all-packed-products.component';
import { AllPlacedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-placed-products/all-placed-products.component';
import { AllReturnedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-returned-products/all-returned-products.component';
import { AllShippedProductsComponent } from './DeliveryStatus/product-tracking-status-operation/all-shipped-products/all-shipped-products.component';
import { AdminServiceService } from './Service/admin-service.service';
import { ThirdPageComponent } from './Third Party/ThirdPage/third-page/third-page.component';
import { AddPartyComponent } from './Third Party/Operation/AddParty/add-party/add-party.component';
import { ShowPartyComponent } from './Third Party/Operation/ShowParty/show-party/show-party.component';
import { CartManagementComponent } from './cart-management/cart-management.component';
import { ShowCouponComponent } from './Coupon/show-coupon/show-coupon.component';
import { SentComponent} from './FeedBack/operation/sent/sent.component';





@NgModule({
  declarations: [
    AppComponent,
    InteractionComponent,
    HomepageComponent,
    AddComponent,
    ShowComponent,
    AdminCouponComponent,
    FrontPageComponent,
    ProductComponent,
    AddProductComponent,
    UpdateProductComponent,
    CategoryComponent,
    AddCategoryComponent,
    FirstPageComponent,
    CustomerSearchComponent,
    MerchantSearchComponent,
    ProductSearchComponent,
    FeedpageComponent,
    FeedbackComponent,
    ForwardComponent,
    NotForwardComponent,
    TrackOperationComponent,
    AllCancelledProductsComponent,
    AllDeliveredProductsComponent,
    AllPackedProductsComponent,
    AllPlacedProductsComponent,
    AllReturnedProductsComponent,
    AllShippedProductsComponent,
    ThirdPageComponent,
    AddPartyComponent,
    ShowPartyComponent,
    CartManagementComponent,
    ShowCouponComponent,SentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
   

  ],
  providers: [HttpClient,AdminServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
