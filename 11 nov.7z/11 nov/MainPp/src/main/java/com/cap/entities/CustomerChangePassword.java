package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_customerchangepassword")
public class CustomerChangePassword {
	    
    @Id
    @Column(length=30)
    private String customer_Email;
    
    @Column(length=20)
    private String customer_CurrentPassword;
    
    @Column(length=20)
    private String customer_NewPassword;
    
    
    //toString
    @Override
    public String toString() {
        return "CustomerChangePassword [customer_Email=" + customer_Email + ", customer_CurrentPassword="
                + customer_CurrentPassword + ", customer_NewPassword=" + customer_NewPassword + "]";
    }
    
    //Getters And Setters
    public String getCustomer_Email() {
        return customer_Email;
    }

    public void setCustomer_Email(String customer_Email) {
        this.customer_Email = customer_Email;
    }

    public String getCustomer_CurrentPassword() {
        return customer_CurrentPassword;
    }

    public void setCustomer_CurrentPassword(String customer_CurrentPassword) {
        this.customer_CurrentPassword = customer_CurrentPassword;
    }

    public String getCustomer_NewPassword() {
        return customer_NewPassword;
    }

    public void setCustomer_NewPassword(String customer_NewPassword) {
        this.customer_NewPassword = customer_NewPassword;
    }

    //Parameters Constructor
    public CustomerChangePassword(String customer_Email, String customer_CurrentPassword, String customer_NewPassword) {
        super();
        this.customer_Email = customer_Email;
        this.customer_CurrentPassword = customer_CurrentPassword;
        this.customer_NewPassword = customer_NewPassword;
    }

    //Default Constructor
    public CustomerChangePassword() {
        super();
    }  
}