package com.cap.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_transaction")
public class TransactionDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_seq_gen")
	@SequenceGenerator(name = "transaction_seq_gen", initialValue = 1000, sequenceName = "transaction_seq")
	private long transactionId;

	 @ManyToOne
	 @JoinColumn
	 private Product product;
	    
	 @ManyToOne
	 @JoinColumn(name = "email")
	 private Merchant merchant;
	 
	 @ManyToOne
	 @JoinColumn
	 private Order order;
	 
	 @ManyToOne
	 @JoinColumn
	 private Customer customer;

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public TransactionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionDetails(long transactionId, Product product, Merchant merchant, Order order, Customer customer) {
		super();
		this.transactionId = transactionId;
		this.product = product;
		this.merchant = merchant;
		this.order = order;
		this.customer = customer;
	}
	 
}
