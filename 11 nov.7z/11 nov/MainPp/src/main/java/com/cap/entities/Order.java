package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_orders")
public class Order {
	
	 @Id
	 @GeneratedValue
	 @Column(length=20)
	 private long order_Id;
	    
	 @Column(length=20)
	 private String order_Date;
	    
	 @ManyToOne
	 @JoinColumn
	 private Product product;
	    
	 @ManyToOne
	 @JoinColumn(name = "email")
	 private Merchant merchant;
	 
	 @Column(length=20)
	 private double totalAmount;
	 
	 @Column(length=20)
	 private String payment_Mode;

	 @Column(length=20)
	 private int quantity;

	public long getOrder_Id() {
		return order_Id;
	}

	public void setOrder_Id(long order_Id) {
		this.order_Id = order_Id;
	}

	public String getOrder_Date() {
		return order_Date;
	}

	public void setOrder_Date(String order_Date) {
		this.order_Date = order_Date;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Merchant getMerchant() {
		return merchant;
	}

	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPayment_Mode() {
		return payment_Mode;
	}

	public void setPayment_Mode(String payment_Mode) {
		this.payment_Mode = payment_Mode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [order_Id=" + order_Id + ", order_Date=" + order_Date + ", product=" + product + ", merchant="
				+ merchant + ", totalAmount=" + totalAmount + ", payment_Mode=" + payment_Mode + ", quantity="
				+ quantity + "]";
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
}
