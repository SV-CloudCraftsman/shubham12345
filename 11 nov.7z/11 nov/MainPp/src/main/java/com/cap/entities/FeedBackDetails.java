package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name="capstore_feedback")
public class FeedBackDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feedback_seq_gen")
	@SequenceGenerator(name = "feedback_seq_gen", initialValue = 100000, sequenceName = "feedback_seq")
	private long feedBackId;
	
	@Column(length=20)
	 private int customer_id;
	 
	 @Column
	 @Min(150)
	 @Max(1000)
	 private String feedBackComment;


	 @ManyToOne
	 @JoinColumn
	 private Product product;
	 
	 @Column(length=10)
	 private float rate;

	public long getFeedBackId() {
		return feedBackId;
	}

	public void setFeedBackId(long feedBackId) {
		this.feedBackId = feedBackId;
	}

	

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getFeedBackComment() {
		return feedBackComment;
	}

	public void setFeedBackComment(String feedBackComment) {
		this.feedBackComment = feedBackComment;
	}

	public float getRate() {
		return rate;
	}

	public void setRate(float rate) {
		this.rate = rate;
	}

	public FeedBackDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FeedBackDetails(long feedBackId, int id, @Min(150) @Max(1000) String feedBackComment, float rate) {
		super();
		this.feedBackId = feedBackId;
		this.customer_id =id;
		this.feedBackComment = feedBackComment;
		this.rate = rate;
	}
	 	
}
