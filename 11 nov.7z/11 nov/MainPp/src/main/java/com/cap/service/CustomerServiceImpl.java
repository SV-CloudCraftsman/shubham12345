package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.CartRepo;
import com.cap.dao.CustomerRepo;
import com.cap.dao.MerchantRepo;
import com.cap.dao.ProductRepo;
import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Product;

@Service
public class CustomerServiceImpl implements Customerservice {
	@Autowired
	CustomerRepo customerRepo;
	@Autowired
	MerchantRepo merchantRepo;
	@Autowired
	ProductRepo productRepo;
	@Autowired
	CartRepo cartRepo;

	@Override
	public Optional<Product> fetchProduct(long productId) {
		// TODO Auto-generated method stub
		return productRepo.findById(productId);
	}

	@Override
	public List<Product> addProducts(Product product) {
			// TODO Auto-generated method stub
			productRepo.save(product);
			return productRepo.findAll();
	}

	@Override
	public Optional<AddToCartProduct> addToCart(long productId,int qty) {
		// TODO Auto-generated method stub
		AddToCartProduct add = null;
		Product p=productRepo.findById(productId).get();
		add.setProductQty(qty);
		add.setProductId(p.getProductId());
		add.setProductName(p.getProductName());
		add.setProductPrice(p.getProductPrice());
		 cartRepo.save(add);
		 return cartRepo.findById((int) productId);
	}

}
