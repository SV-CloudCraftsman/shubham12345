package com.cap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.service.Customerservice;
import com.cap.service.MerchantService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	Customerservice service;
	
	@GetMapping("/fetchProduct/{productId}")
	public Optional<Product> fetchProduct(@PathVariable long productId) {
	return	service.fetchProduct(productId);
	}
	
	@PostMapping("/addProduct")
	public List<Product> addProducts(@RequestBody Product product) {
		return service.addProducts(product);
	}
	
	@PostMapping("/addToCart/{productId}/{qty}")
	public Optional<AddToCartProduct> addToCart(@PathVariable long productId,@PathVariable int qty)
	{
		return service.addToCart(productId,qty);
		
	}

}
