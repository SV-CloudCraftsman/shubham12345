package com.cap.service;

import java.util.List;
import java.util.Optional;

import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Product;

public interface Customerservice {

	Optional<Product> fetchProduct(long productId);

	List<Product> addProducts(Product product);

	Optional<AddToCartProduct> addToCart(long productId,int qty);

}
