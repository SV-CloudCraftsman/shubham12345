package com.cap.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "capstore_wishlists")
public class WishListToCartProduct {

		@Id
		@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wishlist_seq_gen")
		@SequenceGenerator(name = "wishlist_seq_gen", initialValue = 1000, sequenceName = "wishlist_seq_gen")
		private long wishlistId;
		
		@ManyToOne
		@JoinColumn(name="email")
		private Merchant merchant;
		
		@ManyToOne
		@JoinColumn
		private Product products;
		
		public Merchant getMerchant() {
			return merchant;
		}
		public void setMerchant(Merchant merchant) {
			this.merchant = merchant;
		}
		public long getWishlistId() {
			return wishlistId;
		}
		public void setWishlistId(long wishlistId) {
			this.wishlistId = wishlistId;
		}
		public Product getProducts() {
			return products;
		}
		public void setProducts(Product products) {
			this.products = products;
		}

		public WishListToCartProduct() {
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public String toString() {
			return "WishListToCartProduct [wishlistId=" + wishlistId + ", merchant=" + merchant + ", products="
					+ products + "]";
		}
		
		public WishListToCartProduct(long wishlistId, Merchant merchant, Product products) {
			super();
			this.wishlistId = wishlistId;
			this.merchant = merchant;
			this.products = products;
		}
		
}
