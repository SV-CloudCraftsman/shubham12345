package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_addtocarts")
public class AddToCartProduct {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cart_seq_gen")
	@SequenceGenerator(name = "cart_seq_gen", initialValue = 1000, sequenceName = "cart_seq") // to be created
	private long cartId;
	
	@Column
	private long productId;
	
	
	
	@Column
	private int productQty;
	
	@Column
	private String productName;
	
	@Column
	private double productPrice;
	
	

	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	@ManyToOne
	@JoinColumn(name="email")
	private Merchant merchant;
	
	
	
	@ManyToOne
	@JoinColumn
	private Product products;
	
	public long getCartId() {
		return cartId;
	}
	public void setCartId(long cartId) {
		this.cartId = cartId;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public int getProductQty() {
		return productQty;
	}
	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}
	public Product getProducts() {
		return products;
	}
	public void setProducts(Product products) {
		this.products = products;
	}
	public AddToCartProduct() {
		// TODO Auto-generated constructor stub
	}
	
	public AddToCartProduct(long cartId, int productQty, Merchant merchant, Product products) {
		super();
		this.cartId = cartId;
		this.productQty = productQty;
		this.merchant = merchant;
		this.products = products;
	}
	
	@Override
	public String toString() {
		return "AddToCartProduct [cartId=" + cartId + ", productQty=" + productQty + ", merchant=" + merchant
				+ ", products=" + products + "]";
	}
	
	
}