package com.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capstore_customerforgotpassword")
public class CustomerForgotPassword {
    
    @Id
    @Column(length=20)
    private String customer_Email;
    
    @Column(length=20)
    private String customer_NewPassword;
    
    @Column(length=20)
    private String customer_ConformPassword;
    
    //Getters And Setters
    public String getCustomer_Email() {
        return customer_Email;
    }
    public void setCustomer_Email(String customer_Email) {
        this.customer_Email = customer_Email;
    }
    
    
    public String getCustomer_NewPassword() {
        return customer_NewPassword;
    }
    public void setCustomer_NewPassword(String customer_NewPassword) {
        this.customer_NewPassword = customer_NewPassword;
    }
    
    
    public String getCustomer_ConformPassword() {
        return customer_ConformPassword;
    }
    public void setCustomer_ConformPassword(String customer_ConformPassword) {
        this.customer_ConformPassword = customer_ConformPassword;
    }
    
    
    
    //Default Constructor
    public CustomerForgotPassword() {
        super();
    }
    
    
    //Parameter Constructor
    public CustomerForgotPassword(String customer_Email, String customer_NewPassword, String customer_ConformPassword) {
        super();
        this.customer_Email = customer_Email;
        this.customer_NewPassword = customer_NewPassword;
        this.customer_ConformPassword = customer_ConformPassword;
    }
    
    
    //toString
    @Override
    public String toString() {
        return "CustomerForgotPassword [customer_Email=" + customer_Email + ", customer_NewPassword="
                + customer_NewPassword + ", customer_ConformPassword=" + customer_ConformPassword + "]";
    }
    
    
    
    
    
    
}