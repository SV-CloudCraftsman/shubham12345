package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.MerchantRepo;
import com.cap.dao.ProductRepo;
import com.cap.entities.AddToCartProduct;
import com.cap.entities.Merchant;
import com.cap.entities.Product;
import com.cap.entities.WishListToCartProduct;

@Service
public class MerchantServiceImpl implements MerchantService{
	@Autowired
	MerchantRepo repo;
	@Autowired
	ProductRepo repo1;

	@Override
	public List<Merchant> addMerchant(Merchant merchant) {
		repo.save(merchant);
		return repo.findAll();
		
	
	}

	@Override
	public List<Product> addProduct(Product product) {
		repo1.save(product);
		return repo1.findAll();
	}

	@Override
	public List<AddToCartProduct> addCarts(AddToCartProduct addCarts) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WishListToCartProduct> addWishListCarts(WishListToCartProduct wishListCarts) {
		// TODO Auto-generated method stub
		return null;
	}


}
