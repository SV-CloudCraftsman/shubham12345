$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/ramragup/Desktop/Testing/AddressDetails/src/test.resources/AddressDetails/AddressDetails.feature");
formatter.feature({
  "line": 1,
  "name": "HotelBooking",
  "description": "",
  "id": "hotelbooking",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2368596000,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Show AddressDetails page",
  "description": "",
  "id": "hotelbooking;show-addressdetails-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4121412000,
  "status": "passed"
});
formatter.after({
  "duration": 831380900,
  "status": "passed"
});
formatter.before({
  "duration": 1619506600,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Enter Invalid Name",
  "description": "",
  "id": "hotelbooking;enter-invalid-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user does not enter name",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "displays Please fill the Name",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4013337400,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_name()"
});
formatter.result({
  "duration": 347584600,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_Name()"
});
formatter.result({
  "duration": 37516700,
  "status": "passed"
});
formatter.after({
  "duration": 733566300,
  "status": "passed"
});
formatter.before({
  "duration": 1657342300,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Enter Invalid Email",
  "description": "",
  "id": "hotelbooking;enter-invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "user does not enter Email",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "displays Please fill the  Email",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 3715823100,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_Email()"
});
formatter.result({
  "duration": 468457400,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_Email()"
});
formatter.result({
  "duration": 2028752400,
  "status": "passed"
});
formatter.after({
  "duration": 763122800,
  "status": "passed"
});
formatter.before({
  "duration": 1696757000,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Invalid Mobile Number",
  "description": "",
  "id": "hotelbooking;invalid-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "user does not enter mobileNumber",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display Please fill Mobile No.",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4096799500,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_mobileNumber()"
});
formatter.result({
  "duration": 492569100,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.display_Please_fill_Mobile_No()"
});
formatter.result({
  "duration": 2024551400,
  "status": "passed"
});
formatter.after({
  "duration": 817774300,
  "status": "passed"
});
formatter.before({
  "duration": 1588402200,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Wrong Mobile Number",
  "description": "",
  "id": "hotelbooking;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "user enters invalid mobileNumber",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "display Please enter valid Mobile Number",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 11954939600,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_enters_invalid_mobileNumber()"
});
formatter.result({
  "duration": 608801200,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.display_Please_enter_valid_Mobile_Number()"
});
formatter.result({
  "duration": 2037619100,
  "status": "passed"
});
formatter.after({
  "duration": 1068435800,
  "status": "passed"
});
formatter.before({
  "duration": 1370413200,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Enter Invalid Address",
  "description": "",
  "id": "hotelbooking;enter-invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user does not enter address",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "displays Please fill the address",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4112602500,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_address()"
});
formatter.result({
  "duration": 497699000,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_address()"
});
formatter.result({
  "duration": 2026106000,
  "status": "passed"
});
formatter.after({
  "duration": 756519500,
  "status": "passed"
});
formatter.before({
  "duration": 1254209600,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Enter Invalid City",
  "description": "",
  "id": "hotelbooking;enter-invalid-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "user does not enter city",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "displays Please fill the city",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4186428800,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_city()"
});
formatter.result({
  "duration": 664107100,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_city()"
});
formatter.result({
  "duration": 2022152000,
  "status": "passed"
});
formatter.after({
  "duration": 756344300,
  "status": "passed"
});
formatter.before({
  "duration": 1532746600,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "Enter Invalid Zipcode",
  "description": "",
  "id": "hotelbooking;enter-invalid-zipcode",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 38,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "user does not enter zipcode",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "displays Please fill the zipcode",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4320270400,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_zipcode()"
});
formatter.result({
  "duration": 1022290600,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_zipcode()"
});
formatter.result({
  "duration": 2023726800,
  "status": "passed"
});
formatter.after({
  "duration": 827496100,
  "status": "passed"
});
formatter.before({
  "duration": 2066681200,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Enter Invalid State",
  "description": "",
  "id": "hotelbooking;enter-invalid-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 44,
  "name": "user does not enter state",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "displays Please fill the state",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 3891336300,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_does_not_enter_state()"
});
formatter.result({
  "duration": 745637300,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_Please_fill_the_state()"
});
formatter.result({
  "duration": 2043367200,
  "status": "passed"
});
formatter.after({
  "duration": 773785200,
  "status": "passed"
});
formatter.before({
  "duration": 1771152300,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "Valid Payment details",
  "description": "",
  "id": "hotelbooking;valid-payment-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 48,
  "name": "User is on AddressDetails page",
  "keyword": "Given "
});
formatter.step({
  "line": 49,
  "name": "user enters valid  Address details",
  "keyword": "When "
});
formatter.step({
  "line": 50,
  "name": "displays SUCCESSFULLY SHIPPED",
  "keyword": "Then "
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_is_on_AddressDetails_page()"
});
formatter.result({
  "duration": 4273704100,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.user_enters_valid_Address_details()"
});
formatter.result({
  "duration": 892138200,
  "status": "passed"
});
formatter.match({
  "location": "AddressDetailsStepDefinition.displays_SUCCESSFULLY_SHIPPED()"
});
formatter.result({
  "duration": 5346717000,
  "status": "passed"
});
formatter.after({
  "duration": 707403100,
  "status": "passed"
});
});