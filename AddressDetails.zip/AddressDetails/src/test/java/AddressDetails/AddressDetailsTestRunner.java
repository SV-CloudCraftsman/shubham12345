package AddressDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\ramragup\\Desktop\\Testing\\AddressDetails\\src\\test.resources\\AddressDetails\\AddressDetails.feature"},
	    glue= {"AddressDetails"},
	    dryRun = false,
	    monochrome= true,
	    strict=false,
	    format = {"pretty" , "html:test-output"}
		)
public class AddressDetailsTestRunner {

}
