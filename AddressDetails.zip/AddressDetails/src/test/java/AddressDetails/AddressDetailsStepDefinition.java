package AddressDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageFactory.AddressDetailsPageFactory;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class AddressDetailsStepDefinition {
	WebDriver Driver;
	AddressDetailsPageFactory AddressDetails;
	
 @Before
	public void setUp() {
	System.setProperty("webdriver.chrome.driver",
					 "C:\\Users\\ramragup\\Desktop\\Testing Documents\\chromedriver.exe");
	Driver= new ChromeDriver();
		}
	@After
	public void closee()
	    {
	        Driver.quit();
	    }
	
	@Given("^User is on AddressDetails page$")
	public void user_is_on_AddressDetails_page() throws Throwable {
		Driver.get("C:\\Users\\ramragup\\Desktop\\html pages\\cod.component.html");
	    AddressDetails=new AddressDetailsPageFactory(Driver);
	    Thread.sleep(3000);
	}

	@When("^user does not enter name$")
	public void user_does_not_enter_name() throws Throwable {
	    AddressDetails.setName("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the Name$")
	public void displays_Please_fill_the_Name() throws Throwable {
	    String name=Driver.findElement(By.id("fname")).getAttribute("validationMessage");
	    Assert.assertEquals("Please fill out this field.", name);
	}
	
	@When("^user does not enter Email$")
	public void user_does_not_enter_Email() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the  Email$")
	public void displays_Please_fill_the_Email() throws Throwable {
		 String Email=Driver.findElement(By.id("email")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.", Email);
		 Thread.sleep(2000);
	}

	@When("^user does not enter mobileNumber$")
	public void user_does_not_enter_mobileNumber() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^display Please fill Mobile No\\.$")
	public void display_Please_fill_Mobile_No() throws Throwable {
		 String mobileNo=Driver.findElement(By.id("mob")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.",mobileNo );
		 Thread.sleep(2000);
	}

	@When("^user enters invalid mobileNumber$")
	public void user_enters_invalid_mobileNumber() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("4567890321");
	    AddressDetails.setContinuebtn();
	}

	@Then("^display Please enter valid Mobile Number$")
	public void display_Please_enter_valid_Mobile_Number() throws Throwable {
		 String mobileNo=Driver.findElement(By.id("mob")).getAttribute("validationMessage");
		 Assert.assertEquals("Please match the requested format.",mobileNo );
		 Thread.sleep(2000);
	}
	
	@When("^user does not enter address$")
	public void user_does_not_enter_address() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("9567890321");
		AddressDetails.setAddress("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the address$")
	public void displays_Please_fill_the_address() throws Throwable {
		String address=Driver.findElement(By.id("adr")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.",address );
		 Thread.sleep(2000);
	}

	@When("^user does not enter city$")
	public void user_does_not_enter_city() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("9567890321");
		AddressDetails.setAddress("ngnagar");
		AddressDetails.setCity("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the city$")
	public void displays_Please_fill_the_city() throws Throwable {
		String city=Driver.findElement(By.id("city")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.", city);
		 Thread.sleep(2000);
  }
	
	@When("^user does not enter zipcode$")
	public void user_does_not_enter_zipcode() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("9567890321");
		AddressDetails.setAddress("ngnagar");
		AddressDetails.setCity("cbe");
		AddressDetails.setZipcode("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the zipcode$")
	public void displays_Please_fill_the_zipcode() throws Throwable {
		
		String zipcode=Driver.findElement(By.id("zip")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.", zipcode);
		 Thread.sleep(2000);
	}

	@When("^user does not enter state$")
	public void user_does_not_enter_state() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("9567890321");
		AddressDetails.setAddress("ngnagar");
		AddressDetails.setCity("cbe");
		AddressDetails.setZipcode("641402");
		AddressDetails.setState("");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays Please fill the state$")
	public void displays_Please_fill_the_state() throws Throwable {
		String state=Driver.findElement(By.id("state")).getAttribute("validationMessage");
		 Assert.assertEquals("Please fill out this field.", state);
		 Thread.sleep(2000);
	}

	
	@When("^user enters valid  Address details$")
	public void user_enters_valid_Address_details() throws Throwable {
		AddressDetails.setName("Jam");
		AddressDetails.setMail("jam123@gmail.com");
		AddressDetails.setMobileNo("9567890321");
		AddressDetails.setAddress("ngnagar");
		AddressDetails.setCity("cbe");
		AddressDetails.setZipcode("641402");
		AddressDetails.setState("TN");
	    AddressDetails.setContinuebtn();
	}

	@Then("^displays SUCCESSFULLY SHIPPED$")
	public void displays_SUCCESSFULLY_SHIPPED() throws Throwable {
		Driver.get("C:\\Users\\ramragup\\Desktop\\html pages\\success-page.component.html");
	     Thread.sleep(5000);
	     Driver.close();
	}


	
}
