package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddressDetailsPageFactory {
	WebDriver Driver;
	
	@FindBy(id="fname")
	@CacheLookup
	WebElement name;
	
	@FindBy(id="email")
	@CacheLookup
	WebElement mail;
	
	@FindBy(id="mob")
	@CacheLookup
	WebElement mobileNo;
			
	@FindBy(id="adr")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(id="zip")
	@CacheLookup
	WebElement zipcode;
	
	@FindBy(id="state")
	@CacheLookup
	WebElement state;

	@FindBy(className="btn")
	@CacheLookup
	WebElement continuebtn;

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail.sendKeys(mail);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	
	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getContinuebtn() {
		return continuebtn;
	}

	public void setContinuebtn() {
		this.continuebtn.click();
	}

	public AddressDetailsPageFactory(WebDriver driver) {
		 this.Driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	
	
	
}
