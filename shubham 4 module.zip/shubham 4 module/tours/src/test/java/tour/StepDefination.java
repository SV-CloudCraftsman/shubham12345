package tour;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import factory.TourFactory;

public class StepDefination {
	
	
	public WebDriver Driver;
	public TourFactory NewTours_OR;
	@Before
	public void SetUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shuvishw\\Desktop\\Chrome\\chromedriver.exe");
		Driver = new ChromeDriver();
		Driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		Driver.manage().deleteAllCookies();
		NewTours_OR = new TourFactory(Driver);
		Driver.get("http://www.newtours.demoaut.com/");
	}
	
	@After
	public void Tear_Down() {
		Driver.quit();
	}
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page() {
		String ttl = Driver.getTitle();
		Assert.assertEquals("Yes, User is on Login Page", "Welcome: Mercury Tours", ttl);
	}

	@Then("^the user enter mercury as \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enter_mercury_as_and(String Usname, String Pswd) throws InterruptedException {
		NewTours_OR.setUName_Txt(Usname);
		NewTours_OR.setPwd_Txt(Pswd);
		Thread.sleep(2000);
	}

	@Then("^click on sign in button$")
	public void click_on_sign_in_button() {
		NewTours_OR.setSignIn_Btn();
	}

	@Given("^the user is on Flight reservation page$")
	public void the_user_is_on_Flight_reservation_page() {
		String FR_TTL = Driver.getTitle();
		Assert.assertEquals("Yes, User is on FR Page", "Find a Flight: Mercury Tours:", FR_TTL);
	}

	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable PassCount) throws InterruptedException {
		List<String> P_Num = PassCount.asList(String.class);
		for(String P: P_Num) {
			NewTours_OR.setPass_Count(P);
			Thread.sleep(2000);
		}
	}

	@Then("^user to enter \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void user_to_enter_and_location(String Departure, String Arrival) throws InterruptedException {
		NewTours_OR.setDepart_Loc(Departure);
		Thread.sleep(2000);
		NewTours_OR.setArrival_Loc(Arrival);
		Thread.sleep(2000);
	}
	

	@Then("^click on continue booking$")
	public void click_on_continue_booking() {
		NewTours_OR.setCont_Booking();
	}
}
