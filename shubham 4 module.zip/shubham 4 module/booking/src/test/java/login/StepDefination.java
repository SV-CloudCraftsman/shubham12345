package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factory.BookingPageFactory;
import factory.LoginFactory;
import junit.framework.Assert;

public class StepDefination {
	public WebDriver driver;
	public BookingPageFactory booking;
	public LoginFactory factory;

@Given("^user is on login page$")
public void user_is_on_login_page() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\shuvishw\\Desktop\\Chrome\\chromedriver.exe");
    driver = new ChromeDriver();
    driver.get("C:\\Users\\shuvishw\\Desktop\\BDDCaseStudyFinal\\login.html");
    factory= new LoginFactory(driver);
    
}

@Then("^check login page heading as Hotel Booking Application$")
public void check_login_page_heading_as_Hotel_Booking_Application() throws InterruptedException {
	Thread.sleep(5000);
	String bodyText=driver.findElement(By.tagName("h1")).getText();
	System.out.println(bodyText);
	Assert.assertEquals("Hotel Booking Application", bodyText);
	driver.close();
	
}

@When("^user enters valid username and password$")
public void user_enters_valid_username_and_password() throws InterruptedException {
	Thread.sleep(5000);
	factory.setUserName("Yogini");
	Thread.sleep(3000);
	factory.setPassword("Yogini");
	Thread.sleep(3000);
	
}

@When("^clicks login button$")
public void clicks_login_button() {
	factory.setLoginButton();
}

@Then("^navigate to hotel booking form$")
public void navigate_to_hotel_booking_form() throws InterruptedException {
	Thread.sleep(5000);
	String hotelBookingForm=driver.findElement(By.tagName("h2")).getText();
	Assert.assertEquals("Hotel Booking Form", hotelBookingForm);
	driver.close();
	
}

@When("^user left username field empty$")
public void user_left_username_field_empty() {
	factory.setUserName("");
	factory.setLoginButton();
	
}

@Then("^give error message as Please enter UserName$")
public void give_error_message_as_Please_enter_UserName() throws InterruptedException{
	Thread.sleep(5000);
	String errMsg = factory.getUsernameError();
	
	//String errMsg=driver.findElement(By.id("userErrMsg")).getText();
	Assert.assertEquals("* Please enter userName.", errMsg);
	driver.close();
	
}

@When("^user left password field empty$")
public void user_left_password_field_empty(){
	factory.setUserName("Yogini");
	factory.setPassword("");
	factory.setLoginButton();
}

@Then("^give error message as Please enter Password$")
public void give_error_message_as_Please_enter_Password() throws InterruptedException {
	Thread.sleep(5000);
	String errMsg1=driver.findElement(By.id("pwdErrMsg")).getText();
	Assert.assertEquals("* Please enter password.", errMsg1);
	driver.close();
}



	

}
