package factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookingPageFactory {
	WebDriver driver;
	
	//step 1 : identify elements
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public String getEmail() {
		return email.getText();
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public int getPersonCount() {
		return personCount;
	}

	public WebElement getRooms() {
		return rooms;
	}

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public WebElement getDebitNo() {
		return debitNo;
	}

	public WebElement getCvv() {
		return cvv;
	}

	public WebElement getExpiryMonth() {
		return expiryMonth;
	}

	public WebElement getYear() {
		return year;
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;

	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;

	@FindBy(name="persons")
	@CacheLookup
	int personCount;

	@FindBy(id="rooms")
	@CacheLookup
	WebElement rooms;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;

	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitNo;

	@FindBy(name="cvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expiryMonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement confirmButton;
	

	public BookingPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);;
	}

	public void setCity(String Inputcity) {
		Select City_Select = new Select(city);
		City_Select.selectByVisibleText(Inputcity);
	}

	public void setState(String Inputstate) {
		Select State_Select = new Select(state);
		State_Select.selectByVisibleText(Inputstate);
	}

	public void setPersonCount(int persons) {
		this.personCount=persons;
	}

	public void setRooms(WebElement rooms) {
		this.rooms = rooms;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);;
	}

	public void setDebitNo(String debitNo) {
		this.debitNo.sendKeys(debitNo);;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);;
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);;
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

	public WebElement getCity() {
		Select City_Select = new Select(city);
		return City_Select.getFirstSelectedOption();
		
	}

	public WebElement getState() {
		
		Select State_Select = new Select(state);
		return State_Select.getFirstSelectedOption();
	}
	
	
	

}
