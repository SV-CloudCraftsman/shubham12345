$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/shubham/booking/src/test/resources/booking.feature");
formatter.feature({
  "line": 1,
  "name": "Validating Hotel Booking Form",
  "description": "",
  "id": "validating-hotel-booking-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Verify the title “Hotel Booking” of the page",
  "description": "",
  "id": "validating-hotel-booking-form;verify-the-title-“hotel-booking”-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "verify the heading as Hotel Booking Form",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 3183780300,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.verify_the_heading_as_Hotel_Booking_Form()"
});
formatter.result({
  "duration": 3230887600,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "the alert box displays the message “Please fill the First Name” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-first-name”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user left the First Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "it will pop-up the alert box displays the message “Please fill the First Name”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1421750300,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_First_Name_field_empty()"
});
formatter.result({
  "duration": 3082471800,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 70560600,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_First_Name()"
});
formatter.result({
  "duration": 9219516600,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "the alert box displays the message “Please fill the Last Name” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-last-name”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user left the Last Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "it will pop-up the alert box displays the message “Please fill the Last Name”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1400341000,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_Last_Name_field_empty()"
});
formatter.result({
  "duration": 9192766200,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 75171000,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 9200933800,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "the alert box will pop a message \"Please fill the email\" upon wrong email format entered in text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-will-pop-a-message-\"please-fill-the-email\"-upon-wrong-email-format-entered-in-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "user gives wrong email format",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "it will pop-up the alert box displays the message “Please enter valid Email Id.”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 2151773800,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_gives_wrong_email_format()"
});
formatter.result({
  "duration": 6306575400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 61306400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_enter_valid_Email_Id()"
});
formatter.result({
  "duration": 3182124000,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "the alert box displays the message “Please fill the Email” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-email”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user left the Email field empty",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "it will pop-up the alert box displays the message “Please fill the Email”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 2306075500,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_Email_field_empty()"
});
formatter.result({
  "duration": 6248860700,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 63132500,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Email()"
});
formatter.result({
  "duration": 9204931900,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "the alert box displays the message “Please enter valid Email Id.” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-enter-valid-email-id.”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "user entered wrong format of Email",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "it will pop-up the alert box displaying the message “Please enter valid Email Id.”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1832441000,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_entered_wrong_format_of_Email()"
});
formatter.result({
  "duration": 6281230300,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 65597900,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displaying_the_message_Please_enter_valid_Email_Id()"
});
formatter.result({
  "duration": 9169190000,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "the alert box displays the message “Please fill the Mobile No.” upon clicking on the button “Confirm Booking” without entering any data in the text box",
  "description": "",
  "id": "validating-hotel-booking-form;the-alert-box-displays-the-message-“please-fill-the-mobile-no.”-upon-clicking-on-the-button-“confirm-booking”-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "user left the Mobile No field empty",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "it will pop-up the alert box displays the message “Please fill the Mobile No.”",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 2062870100,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_left_the_Mobile_No_field_empty()"
});
formatter.result({
  "duration": 9390148300,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 62327400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Mobile_No()"
});
formatter.result({
  "duration": 9165808800,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "user has not selected any value from city",
  "description": "",
  "id": "validating-hotel-booking-form;user-has-not-selected-any-value-from-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "user has not selected any option from city",
  "keyword": "Then "
});
formatter.step({
  "line": 47,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 48,
  "name": "it will pop-up the alert box displays the message “Please select city\"",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1981010200,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_has_not_selected_any_option_from_city()"
});
formatter.result({
  "duration": 12463164400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 61122100,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_select_city()"
});
formatter.result({
  "duration": 9166178700,
  "status": "passed"
});
formatter.scenario({
  "line": 50,
  "name": "user has not selected any value from state",
  "description": "",
  "id": "validating-hotel-booking-form;user-has-not-selected-any-value-from-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 51,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 52,
  "name": "user has not selected any option from state",
  "keyword": "Then "
});
formatter.step({
  "line": 53,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 54,
  "name": "it will pop-up the alert box displays the message “Please select state\"",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1925487400,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_has_not_selected_any_option_from_state()"
});
formatter.result({
  "duration": 12595493700,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 61333500,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_pop_up_the_alert_box_displays_the_message_Please_select_state()"
});
formatter.result({
  "duration": 9183312200,
  "status": "passed"
});
formatter.scenario({
  "line": 56,
  "name": "user has passedd every value and navigate to another page",
  "description": "",
  "id": "validating-hotel-booking-form;user-has-passedd-every-value-and-navigate-to-another-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 57,
  "name": "user is on Hotel Booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 58,
  "name": "user has given all the values",
  "keyword": "Then "
});
formatter.step({
  "line": 59,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 60,
  "name": "it will go to Booking Completed page",
  "keyword": "Then "
});
formatter.match({
  "location": "BookingStepDefination.user_is_on_Hotel_Booking_page()"
});
formatter.result({
  "duration": 1827201200,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.user_has_given_all_the_values()"
});
formatter.result({
  "duration": 31150871100,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 125138700,
  "status": "passed"
});
formatter.match({
  "location": "BookingStepDefination.it_will_go_to_Booking_Completed_page()"
});
formatter.result({
  "duration": 3243818100,
  "status": "passed"
});
});